"""
Seeds an ISOLATED SQLite database for the browser runtime check (CI only).
Refuses to run unless TESTING=true and DATABASE_URL is a local sqlite file.
Writes test-only JWTs to /tmp/nabbah_runtime_tokens.json (never committed).
"""
import json, os, sys
from datetime import datetime
url = os.environ.get("DATABASE_URL", "")
if os.environ.get("TESTING") != "true" or not url.startswith("sqlite") or any(x in url.lower() for x in ("railway", "rlwy")):
    sys.exit("Refusing: set TESTING=true and a local sqlite DATABASE_URL.")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import main as m
from sqlmodel import Session, SQLModel
SQLModel.metadata.drop_all(m.engine); SQLModel.metadata.create_all(m.engine)
with Session(m.engine) as s:
    def company(name, email, branches):
        u = m.User(name=name + " owner", email=email, password_hash=m.hash_password("Runtime12345"))
        s.add(u); s.commit(); s.refresh(u)
        c = m.Company(name=name, owner_id=u.id, is_active=1, target_margin=25, currency="SAR")
        s.add(c); s.commit(); s.refresh(c); u.company_id = c.id; s.add(u); s.commit(); s.refresh(u)
        ids = []
        for bname, target, series in branches:
            b = m.CompanyBranch(company_id=c.id, name=bname, is_active=1, target_sales=target)
            s.add(b); s.commit(); s.refresh(b); ids.append(b.id)
            for month, (sales, exp, cust) in zip(range(4, 10), series):
                s.add(m.CompanyEntry(company_id=c.id, branch_id=b.id, branch_name=bname, period=f"2026-{month:02d}",
                                     sales=sales, invoices=max(1, sales // 90), customers=cust, repeat_customers=cust // 4, expenses=exp))
        s.commit()
        return u, c, ids
    owner, ca, (riyadh, makkah) = company("شركة العرض", "owner@runtime.test", [
        ("فرع الرياض", 110000, [(90000 + i * 3000, 62000, 900) for i in range(6)]),
        ("فرع مكة", 50000, [(60000 - i * 2500, 44000, 0 if i == 5 else 400) for i in range(6)])])
    other, cb, _ = company("Other Co", "other@runtime.test", [("B1", 0, [(999999, 1, 10)] * 6)])
    s.add(m.CompanyModuleEntry(company_id=ca.id, module="finance", period="2026-09", data=json.dumps(
        {"تكلفة البضاعة المباعة": 70000, "الرواتب": 25000, "الإيجار": 9000, "التسويق": 4000}, ensure_ascii=False)))
    s.add(m.CompanyDecision(company_id=ca.id, title="مراجعة تكلفة المواد — فرع مكة", owner="مدير الفرع", status="open",
                            kpi="gross_margin", metric_id="gross_margin", branch_id=makkah, problem_type="negative_margin_branch",
                            decision_type="profitability", baseline_value=-9.3, expected_impact_value=4000,
                            impact_status="expected", outcome_status="pending_measurement", created_by="seed",
                            created_at=datetime(2026, 6, 10)))
    s.commit()
    json.dump({"owner": m.create_token(owner.id), "other": m.create_token(other.id)}, open("/tmp/nabbah_runtime_tokens.json", "w"))
print("seeded isolated runtime DB")
