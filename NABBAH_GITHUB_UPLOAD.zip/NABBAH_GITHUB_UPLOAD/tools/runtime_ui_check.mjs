// Browser runtime check against the REAL running app (uvicorn main:app). CI only.
// Creates data through the real API, captures screenshots, and fails on console errors,
// server errors, failing Phase 2.3 requests, or raw codes leaking into Arabic text.
import { chromium } from "playwright";
import fs from "node:fs";
const BASE = process.env.NABBAH_URL || "http://127.0.0.1:8000";
const OUT = "docs/screenshots/phase23-runtime";
fs.mkdirSync(OUT, { recursive: true });
const tok = JSON.parse(fs.readFileSync("/tmp/nabbah_runtime_tokens.json", "utf8"));
const api = async (path, method = "GET", body) => {
  const r = await fetch(BASE + path, { method, headers: { Authorization: "Bearer " + tok.owner, "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(j)}`); return j;
};
// ── real data through the real API
await api("/company/scenarios", "POST", { name: "خطة النمو", scenario_type: "growth", description: "زيادة المبيعات 10%", assumptions: { revenue_growth_pct: 10 } });
await api("/company/scenarios", "POST", { name: "خفض تكلفة البضاعة", scenario_type: "cost_reduction", assumptions: { cogs_change_pct: -5 } });
const ei = await api("/company/executive-intelligence");
const sig = [...ei.risks, ...ei.opportunities][0];
const dec = await api("/company/recommendations/to-decision", "POST", { signal_id: sig.id, owner: "مدير الفرع", due_date: "2026-10-15" });
await api("/company/actions", "POST", { decision_id: dec.decision_id, title: "مقارنة التكاليف بين الفروع", owner: "المحاسب", due_date: "2026-09-01", priority: "P2" });
await api("/company/actions/update", "POST", { id: dec.action_ids[0], status: "in_progress", progress: 40, note: "بدأنا مراجعة الأسعار" });
const all = await api("/company/decision-memory?metric_id=gross_margin&problem_type=negative_margin_branch");
for (const it of all.items) await api("/company/decisions/measure", "POST", { decision_id: it.id });

const report = { pages: [], critical: [], warnings: [] };
const P23 = /\/company\/(scenarios|actions|decision|executive-intelligence|recommendations)/;
const LEAK = /\b(gross_margin|negative_margin_branch|not_started|in_progress|expense_ratio|repeat_rate|[0-9a-f]{12})\b/;
const b = await chromium.launch();
async function shot(name, path, { lang = "ar", w = 1280, h = 900, act, full = true, leakCheck = lang === "ar" } = {}) {
  const ctx = await b.newContext({ viewport: { width: w, height: h } });
  await ctx.addInitScript(([t, l]) => { localStorage.setItem("nabbah_token", t); localStorage.setItem("nabbah_lang", l); }, [tok.owner, lang]);
  const p = await ctx.newPage(); const rec = { name, path, lang, width: w, console: [], http: [] };
  p.on("console", (m) => m.type() === "error" && rec.console.push(m.text()));
  p.on("pageerror", (e) => rec.console.push("pageerror: " + e.message));
  p.on("requestfailed", (r) => rec.http.push(`FAILED ${r.url()} ${r.failure()?.errorText}`));
  p.on("response", (r) => r.status() >= 400 && rec.http.push(`${r.status()} ${r.request().method()} ${r.url().replace(BASE, "")}`));
  await p.goto(BASE + path, { waitUntil: "networkidle" }); await p.waitForTimeout(900);
  if (act) await act(p); await p.waitForTimeout(600);
  await p.screenshot({ path: `${OUT}/${name}.png`, fullPage: full });
  if (leakCheck) {
    const txt = await p.evaluate(() => { const c = document.body.cloneNode(true); c.querySelectorAll("details,code,script,style").forEach((e) => e.remove()); return c.innerText; });
    const m = txt.match(LEAK); if (m) rec.console.push("i18n leak: " + m[0]);
  }
  for (const c of rec.console) report.critical.push(`${name}: ${c}`);
  for (const h of rec.http) (/^(5\d\d|FAILED)/.test(h) || P23.test(h) ? report.critical : report.warnings).push(`${name}: ${h}`);
  report.pages.push(rec); await ctx.close();
}
const openDetails = async (p) => { await p.$$eval("#nbExecIntel details", (ds) => ds.forEach((d) => (d.open = true))); const m = await p.$("[data-mem]"); if (m) { await m.click(); await p.waitForTimeout(700); } };
await shot("01_exec_intel_ar", "/company-dashboard.html");
await shot("02_exec_intel_en", "/company-dashboard.html", { lang: "en" });
await shot("03_scenarios_ar", "/company-scenarios.html");
await shot("04_scenarios_en", "/company-scenarios.html", { lang: "en" });
await shot("05_scenario_create_edit", "/company-scenarios.html", { full: false, act: async (p) => { await p.click("#newBtn"); await p.fill("#fName", "اختبار"); await p.fill("#a_revenue_growth_pct", "999"); await p.click("#fSave"); await p.waitForTimeout(700); } });
await shot("06_action_center_ar", "/company-actions.html");
await shot("07_action_center_en", "/company-actions.html", { lang: "en", act: async (p) => p.click("#vTable") });
await shot("08_action_drawer", "/company-actions.html", { full: false, act: async (p) => { await p.click(".card"); await p.waitForTimeout(900); } });
await shot("09_decision_memory", "/company-actions.html", { act: async (p) => { await p.click(".card"); await p.waitForTimeout(900); await p.$eval("#mem", (e) => e.scrollIntoView()); } });
await shot("10_mobile_actions", "/company-actions.html", { w: 390, h: 844 });
await shot("11_mobile_exec_intel", "/company-dashboard.html", { w: 390, h: 844 });
await shot("12_data_quality_localized_rules", "/company-dashboard.html", { act: openDetails });
await shot("13_tablet_actions", "/company-actions.html", { w: 820, h: 1180 });
// tenant isolation seen from the browser: the other company sees none of this data
const iso = await fetch(BASE + "/company/actions", { headers: { Authorization: "Bearer " + tok.other } }).then((r) => r.json());
if (iso.count !== 0) report.critical.push("isolation: other company sees actions");
await b.close();
fs.writeFileSync(`${OUT}/runtime-report.json`, JSON.stringify(report, null, 2));
console.log(`pages: ${report.pages.length} | critical: ${report.critical.length} | warnings: ${report.warnings.length}`);
report.critical.forEach((c) => console.log("CRITICAL", c));
process.exit(report.critical.length ? 1 : 0);
