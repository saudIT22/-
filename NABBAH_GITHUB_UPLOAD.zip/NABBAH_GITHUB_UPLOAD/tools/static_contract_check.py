"""
Static verification that needs no server or database (runs anywhere):
  1. Frontend -> backend contract: every fetch() URL + method used by the Phase 2.3 pages exists in main.py.
  2. Tenant scope: every new endpoint calls a scope/permission guard, and every s.get(Model, id)
     on a company-owned model is followed by a company_id check.
  3. Migration consistency: model fields == migration SQL columns == auto_sync list.
  4. Hygiene: no console.log / print debugging / conflict markers in production files.
Exit code 1 on any finding.
"""
import ast, os, re, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
src = open(os.path.join(ROOT, "main.py"), encoding="utf-8").read()
tree = ast.parse(src)
problems, notes = [], []

# ── routes in main.py
routes = {}
for n in ast.walk(tree):
    if isinstance(n, ast.FunctionDef):
        for d in n.decorator_list:
            if isinstance(d, ast.Call) and getattr(d.func, "attr", "") in ("get", "post", "put", "delete") and d.args \
                    and isinstance(d.args[0], ast.Constant):
                routes[(d.func.attr.upper(), d.args[0].value)] = n
def route_match(method, url):
    for (m, path) in routes:
        rx = "^" + re.sub(r"\{[^}]+\}", r"[^/]+", path) + "$"
        if m == method and re.match(rx, url):
            return True
    return False

# ── 1. contract
for page in ("company-actions.html", "company-scenarios.html", "nabbah-exec-intel.js"):
    t = open(os.path.join(ROOT, page), encoding="utf-8").read()
    for m in re.finditer(r'fetch\(\s*([`"])(/[^`"?]*)', t):
        url = re.sub(r"\$\{[^}]+\}", "1", m.group(2))
        tail = t[m.end():m.end() + 160]
        mm = re.search(r'method\s*:\s*(?:s\s*\?\s*"(\w+)"\s*:\s*)?"?(\w+)"?', tail)
        methods = {"GET"}
        if mm:
            methods = {x.upper() for x in mm.groups() if x and x.upper() in ("GET", "POST", "PUT", "DELETE")}
            if not methods and "method" in tail and "method," in tail.replace(" ", ""):
                methods = {"POST", "DELETE"}   # act(url, method) helper: callers pass POST/DELETE
        for meth in methods:
            if not route_match(meth, url):
                problems.append(f"contract: {page} calls {meth} {url} — no such route in main.py")
    notes.append(f"contract: checked fetch() calls in {page}")
# calls whose URL is built in a variable (act()/form helpers) — listed explicitly
for meth, url in (("POST", "/company/scenarios"), ("PUT", "/company/scenarios/1"), ("POST", "/company/scenarios/1/run"),
                  ("DELETE", "/company/scenarios/1"), ("POST", "/company/actions/update")):
    if not route_match(meth, url):
        problems.append(f"contract: dynamic call {meth} {url} — no such route")

# ── 2. tenant scope for Phase 2.3 endpoints
GUARDS = ("_exec_scope", "_scenario_scope", "_decisions_scope", "check_permission", "_own_scenario", "owner_id != user.id")
OWNED = ("CompanyDecision", "CompanyAction", "CompanyScenario", "CompanyBranch")
new_paths = [p for (_, p) in routes if any(k in p for k in ("scenarios", "actions", "decision", "executive-intelligence", "recommendations"))]
for (m, p), fn in routes.items():
    if p not in new_paths or p.endswith((".html", ".js")):
        continue  # static page/asset files carry no data; their API calls are checked above
    body = ast.get_source_segment(src, fn)
    if not any(g in body for g in GUARDS):
        problems.append(f"scope: {m} {p} has no permission/scope guard")
    for g in re.finditer(r"(\w+)\s*=\s*s\.get\((\w+),", body):
        var, model = g.groups()
        if model in OWNED and not re.search(rf"{var}\.company_id\s*!=\s*company\.id|not {var} or {var}\.company_id", body):
            problems.append(f"scope: {m} {p} loads {model} into '{var}' without a company_id check")
notes.append(f"scope: audited {len(new_paths)} Phase 2.3 routes")

# ── 3. migrations vs models vs auto_sync
def model_fields(name):
    for n in tree.body:
        if isinstance(n, ast.ClassDef) and n.name == name:
            return [s.target.id for s in n.body if isinstance(s, ast.AnnAssign)]
    return []
sql = ""
for f in ("2_3_001_decisions_actions.sql", "2_3_002_scenarios_memory.sql"):
    sql += open(os.path.join(ROOT, "docs", "migrations", f), encoding="utf-8").read()
def sql_table_cols(table):
    m = re.search(rf"CREATE TABLE IF NOT EXISTS {table} \((.*?)\);", sql, re.S)
    body = re.sub(r"--[^\n]*", "", m.group(1)) if m else ""
    return {c.strip().split()[0] for part in body.split("\n") for c in part.split(",") if c.strip() and c.strip()[0].isalpha()}
for model, table in (("CompanyAction", "companyaction"), ("CompanyScenario", "companyscenario")):
    mf, sc = set(model_fields(model)), sql_table_cols(table)
    if mf != sc:
        problems.append(f"migration: {table} model/SQL mismatch — only in model: {sorted(mf - sc)}, only in SQL: {sorted(sc - mf)}")
dec = model_fields("CompanyDecision")
new_dec = dec[dec.index("closed_at") + 1:]
sync_block = re.search(r'"companydecision":\s*\[(.*?)\]', src, re.S).group(1)
sql_dec = set(re.findall(r"ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS (\w+)", sql))
for f in new_dec:
    if f'"{f}"' not in sync_block:
        problems.append(f"migration: CompanyDecision.{f} missing from auto_sync_columns — existing Postgres DBs would never get it")
    if f not in sql_dec:
        problems.append(f"migration: CompanyDecision.{f} missing from migration SQL")
notes.append(f"migration: {len(new_dec)} new decision columns, 2 new tables checked")

# ── 4. hygiene
for f in ("company-actions.html", "company-scenarios.html", "nabbah-exec-intel.js", "phase23/scenario_engine.py",
          "phase23/decision_memory.py", "phase23/rule_catalog.py", "phase23/intelligence_engine.py", "phase23/forecast_engine.py"):
    t = open(os.path.join(ROOT, f), encoding="utf-8").read()
    if "console.log" in t: problems.append(f"hygiene: console.log in {f}")
    if f.endswith(".py") and re.search(r"^\s*print\(", t, re.M): problems.append(f"hygiene: print() in {f}")
    if re.search(r"^(<<<<<<<|>>>>>>>)", t, re.M): problems.append(f"hygiene: conflict marker in {f}")
if re.search(r"MockProvider|fx_|srv2", src): problems.append("hygiene: test doubles referenced from main.py")

for n in notes: print("OK  ", n)
for p in problems: print("FAIL", p)
print(f"\nRESULT: {len(problems)} problem(s)")
sys.exit(1 if problems else 0)
