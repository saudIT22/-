"""
READ-ONLY rounding impact report (Option B migration plan, step 1).

Counts how many stored CompanyEntry rows would change if ACCOUNTING_HALF_UP
replaced LEGACY_COMPATIBLE. Never writes. Run it on a NON-PRODUCTION COPY:

  ALLOW_READONLY_REPORT=1 DATABASE_URL=postgresql://...copy... python tools/rounding_impact_report.py

Growth is not recomputed here (it needs the previous period); branch_score is
re-derived from the changed fields.
"""
import os, sys
from collections import Counter
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "phase22"))
from legacy_adapters import central_company_metrics
from nabbah_finance import LEGACY_COMPATIBLE as L, ACCOUNTING_HALF_UP as H

if os.environ.get("ALLOW_READONLY_REPORT") != "1":
    sys.exit("Refusing to run: set ALLOW_READONLY_REPORT=1 and point DATABASE_URL at a COPY.")
from sqlalchemy import create_engine, text
eng = create_engine(os.environ["DATABASE_URL"])
fields = ["profit", "margin", "avg_invoice", "repeat_rate"]
total, changed_rows, per_field, companies = 0, 0, Counter(), set()
with eng.connect() as c:
    c.execute(text("SET TRANSACTION READ ONLY")) if eng.dialect.name == "postgresql" else None
    rows = c.execute(text("SELECT id, company_id, sales, invoices, customers, repeat_customers, expenses FROM companyentry"))
    for r in rows:
        total += 1
        args = (r.sales or 0, r.invoices or 0, r.customers or 0, r.repeat_customers or 0, r.expenses or 0)
        a, b = central_company_metrics(*args, None, L), central_company_metrics(*args, None, H)
        diff = [f for f in fields if a[f] != b[f]]
        if diff:
            changed_rows += 1; companies.add(r.company_id); per_field.update(diff)
print(f"companyentry rows scanned : {total}")
print(f"rows that would change    : {changed_rows}")
print(f"companies affected        : {len(companies)}")
for f in fields:
    print(f"  {f:12s}: {per_field[f]}")
print("No data was modified.")
