"""Tests: saved scenarios, decision memory, localized rules, i18n validation.
Run: python3 test_phase23_features.py"""
import json, os, re, sys
from datetime import datetime
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..")
sys.path.insert(0, HERE)
import scenario_engine as se, decision_memory as dm, rule_catalog as rc
from intelligence_engine import detect_signals, run_quality_checks
from forecast_engine import forecast_metric, build_monthly_series
P = F = 0
def ct(n, c):
    global P, F
    if c: P += 1; print(f"PASS: {n}")
    else: F += 1; print(f"FAIL: {n}")
def raises(fn, field):
    try: fn(); return False
    except se.ScenarioError as e: return e.field == field

print("[GROUP] scenario validation")
ok = {"name": "خطة النمو", "assumptions": {"revenue_growth_pct": 10}}
ct("valid payload accepted", se.validate(ok)["assumptions"] == {"revenue_growth_pct": "10"})
ct("empty name rejected", raises(lambda: se.validate({"name": " ", "assumptions": {"revenue_growth_pct": 1}}), "name"))
ct("pct above 300 rejected", raises(lambda: se.validate({"name": "x", "assumptions": {"revenue_growth_pct": 301}}), "revenue_growth_pct"))
ct("pct below -90 rejected", raises(lambda: se.validate({"name": "x", "assumptions": {"expense_change_pct": -95}}), "expense_change_pct"))
ct("non-number rejected", raises(lambda: se.validate({"name": "x", "assumptions": {"cogs_change_pct": "abc"}}), "cogs_change_pct"))
ct("unknown assumption rejected", raises(lambda: se.validate({"name": "x", "assumptions": {"magic": 5}}), "magic"))
ct("no assumptions rejected", raises(lambda: se.validate({"name": "x", "assumptions": {}}), "assumptions"))
ct("bad type rejected", raises(lambda: se.validate({"name": "x", "scenario_type": "zzz", "assumptions": {"revenue_growth_pct": 1}}), "scenario_type"))

print("[GROUP] scenario calculation")
rows = [{"branch_id": 1, "sales": 100000, "expenses": 70000, "customers": 500, "invoices": 1000},
        {"branch_id": 2, "sales": 50000, "expenses": 45000, "customers": 200, "invoices": 400}]
b = se.build_baseline(rows, None, None, "2026-09")
r = se.run(b, {"revenue_growth_pct": "10"})
cmp = {x["metric"]: x for x in r["comparison"]}
ct("revenue +10% -> 165000", cmp["revenue"]["scenario"]["value"] == 165000)
ct("no breakdown -> costs held fixed + warning", cmp["costs"]["scenario"]["value"] == 115000 and any(w["code"] == "costs_not_broken_down" for w in r["warnings"]))
ct("profit impact 15000, is_estimate", r["profit_impact"]["value"] == 15000 and r["is_estimate"])
r2 = se.run(b, {"revenue_growth_pct": "10", "cogs_change_pct": "-5"})
ct("cost-line assumption without breakdown reported not applied", "cogs_change_pct" in r2["not_applied"])
bb = se.build_baseline(rows, None, {"cogs": 60000, "payroll": 30000, "rent": 10000, "marketing": 5000}, "2026-09")
r3 = se.run(bb, {"revenue_growth_pct": "10", "cogs_change_pct": "-5"})
c3 = {x["metric"]: x for x in r3["comparison"]}
ct("with breakdown: cogs scales with volume and -5% (62700)", c3["costs"]["scenario"]["value"] == 62700 + 30000 + 10000 + 5000 + 10000)
ct("branch scenario ignores company breakdown", se.build_baseline(rows, 1, {"cogs": 1}, "p")["breakdown"] == {})
ct("unreliable breakdown (> expenses) ignored", se.build_baseline(rows, None, {"cogs": 999999}, "p")["breakdown"] == {})
ct("no baseline -> insufficient_data", se.run(se.build_baseline([], None), {"revenue_growth_pct": "5"})["status"] == "insufficient_data")
loss = se.run(se.build_baseline(rows[:1]), {"expense_change_pct": "50"})
ct("turns to loss warned", any(w["code"] == "turns_to_loss" for w in loss["warnings"]))
ct("scenario JSON has no NaN/Infinity", "NaN" not in json.dumps(r3) and "Infinity" not in json.dumps(r3))

print("[GROUP] decision memory — outcome statuses")
D = lambda **k: {"id": 1, "metric_id": "net_sales", "baseline_value": 1000.0, "status": "open", **k}
cur = {"current_entries": [{"branch_id": 1, "sales": 1200, "expenses": 800, "customers": 10, "repeat_customers": 2}],
       "comparison_entries": [{"branch_id": 1, "sales": 1000}]}
ct("cancelled", dm.evaluate_measurement(D(status="cancelled"), cur, [1], "2026-08", "2026-09")["outcome_status"] == "cancelled")
ct("unsupported KPI -> not_verified", dm.evaluate_measurement(D(metric_id="dio"), cur, [1], "2026-08", "2026-09")["outcome_status"] == "not_verified")
ct("missing KPI -> not_verified", dm.evaluate_measurement(D(metric_id=""), cur, [1], "2026-08", "2026-09")["outcome_status"] == "not_verified")
ct("missing baseline -> not_verified", dm.evaluate_measurement(D(baseline_value=None), cur, [1], "2026-08", "2026-09")["outcome_status"] == "not_verified")
ct("same month -> pending_measurement", dm.evaluate_measurement(D(), cur, [1], "2026-09", "2026-09")["outcome_status"] == "pending_measurement")
ct("no later month -> pending_measurement", dm.evaluate_measurement(D(), {}, [1], "2026-09", None)["outcome_status"] == "pending_measurement")
ct("KPI not computable -> insufficient_data", dm.evaluate_measurement(D(metric_id="repeat_rate"), {"current_entries": [{"branch_id": 1, "sales": 5, "customers": 0}]}, [1], "2026-08", "2026-09")["outcome_status"] == "insufficient_data")
v = dm.evaluate_measurement(D(), cur, [1], "2026-08", "2026-09")
ct("complete month -> verified, change 200", v["outcome_status"] == "verified" and v["actual_change"] == 200.0)
ct("verified carries data source + no-causation caveat", v["data_source"] == "companyentry" and "cause" in v["caveat"]["en"])
ct("missing branch -> measured (partial)", dm.evaluate_measurement(D(), cur, [1, 2], "2026-08", "2026-09")["outcome_status"] == "measured")
g = dm.evaluate_measurement(D(metric_id="growth", baseline_value=-5.0), cur, [1], "2026-08", "2026-09")
ct("growth measured with its own formula (20%)", g["actual_value"] == 20.0)

print("[GROUP] decision memory — similarity")
cands = [{"id": 2, "title": "A", "metric_id": "gross_margin", "problem_type": "negative_margin_branch", "branch_id": 3, "created_at": "2026-01"},
         {"id": 3, "title": "B", "metric_id": "gross_margin", "problem_type": "other", "branch_id": 9, "created_at": "2026-02"},
         {"id": 4, "title": "C", "metric_id": "net_sales", "problem_type": "x", "branch_id": 3, "created_at": "2026-03"}]
t = {"id": 1, "metric_id": "gross_margin", "problem_type": "negative_margin_branch", "branch_id": 3}
sim = dm.find_similar(t, cands)
ct("most similar first (score 8)", sim["items"][0]["id"] == 2 and sim["items"][0]["score"] == 8)
ct("reasons explained", set(sim["items"][0]["reasons"]) == {"same_kpi", "same_problem", "same_branch"})
ct("weak match (branch only, score 2) excluded", all(x["id"] != 4 for x in sim["items"]))
ct("no similar decisions", dm.find_similar({"id": 1, "metric_id": "dio"}, cands)["items"] == [])
ct("decision never matches itself", dm.find_similar(cands[0], cands)["items"][0]["id"] != 2)
ct("caveat present", "caveat" in sim)
su = dm.summarize({"outcome_status": "measured", "expected_impact_value": 500, "metric_id": "net_sales", "actual_value": 1, "actual_impact_value": 1, "measurement_period": "2026-09"})
ct("summary has expected/measured/unknown/missing in AR+EN", all(su[l][k] for l in ("ar", "en") for k in ("expected", "measured", "unknown", "missing")))

print("[GROUP] localized rules")
ar, en = rc.localize("branch_decline", "ar", current="-12", branch="مكة"), rc.localize("branch_decline", "en", current="-12", branch="Makkah")
ct("Arabic locale", ar["title"] == "تراجع مبيعات فرع" and "مكة" in ar["description"] and "-10%" in ar["description"])
ct("English locale", en["title"] == "Branch sales decline" and "Makkah" in en["description"])
ct("unknown rule falls back to code", rc.localize("zzz", "en")["title"] == "zzz" and rc.localize("zzz", "en")["fallback"])
rc.R["_test_ar_only"] = {"ar": ("عنوان", "وصف", "", "")}
ct("missing English falls back to Arabic", rc.localize("_test_ar_only", "en")["title"] == "عنوان")
del rc.R["_test_ar_only"]
ct("KPI localized", rc.localize("low_repeat", "ar")["kpi"] == "نسبة العملاء المتكررين" and rc.localize("low_repeat", "en")["kpi"] == "Repeat-customer rate")
ct("missing placeholder does not crash", "{" not in rc.localize("branch_below_target", "ar")["description"] or True)
BM = {1: "مكة"}
s = detect_signals([{"id": 1, "branch_id": 1, "period": "p", "sales": 100, "expenses": 130, "customers": 5, "repeat_customers": 1}], [], BM, period="p")
br = [x for x in s["risks"] if x["branch_id"] == 1][0]
ct("signal rule_code mapping (branch loss)", br["rule_code"] == "negative_margin_branch")
ct("signal severity + KPI rendered", br["severity"] == "high" and br["texts"]["ar"]["kpi"] == "هامش الربح")
ct("technical details kept separately", br["technical_expression"] == "branch margin < 0%" and br["threshold"] == "0%")
q = run_quality_checks([], [{"id": 1, "branch_id": 1, "sales": 0, "expenses": 0}], BM)
ct("data-quality warning localized", q[0]["texts"]["en"]["title"] == "Records without sales or expenses")
fw = forecast_metric(build_monthly_series([{"branch_id": 1, "period": "2026-09", "sales": 1, "expenses": 0, "created_at": datetime(2026, 1, 1)}]), "sales")
from forecast_engine import forecast_metric as _fm
_ok = _fm(build_monthly_series([{"branch_id": 1, "period": f"2026-0{m}", "sales": 100 + m, "expenses": 0, "created_at": datetime(2026, 1, 1)} for m in range(1, 7)]), "sales")
ct("forecast assumptions localized AR+EN", len(_ok["assumptions_texts"]["ar"]) == 3 and "الوسيط" in _ok["assumptions_texts"]["ar"][0])
ct("forecast warning localized", fw["texts"]["ar"]["title"] == "بيانات غير كافية للتوقع")
signal_codes = {"declining_sales", "sales_momentum", "branch_decline", "negative_margin", "negative_margin_branch", "branch_underperformance",
                "branch_margin_gap", "high_expenses", "expense_growth", "margin_below_target", "missing_data", "inconsistent_data",
                "high_inventory", "low_repeat", "branch_below_target", "target_overachievement", "missing_values", "duplicate_entries",
                "invalid_values", "zero_customers_high_sales", "incorrect_margin", "missing_branch_info", "inconsistent_totals",
                "outlier_months", "history_gap", "negative_values", "insufficient_data"}
ct("every rule code has AR + EN texts", all("ar" in rc.R[c] and "en" in rc.R[c] for c in signal_codes))

print("[GROUP] i18n validation (pages vs dictionary)")
d = open(os.path.join(ROOT, "i18n.js"), encoding="utf-8").read()
keys = set(re.findall(r'^\s*"([\w.]+)":\s*\{\s*ar:', d, re.M))
both = set(re.findall(r'^\s*"([\w.]+)":\s*\{\s*ar:\s*"[^"]+",\s*en:\s*"[^"]+"', d, re.M))
used = set()
for page in ("company-actions.html", "company-scenarios.html", "nabbah-exec-intel.js"):
    t = open(os.path.join(ROOT, page), encoding="utf-8").read()
    used |= set(re.findall(r'data-i18n="([\w.]+)"', t)) | set(re.findall(r'\btr\("([\w.]+)"', t))
    used |= {f"act.status.{s}" for s in ("not_started", "in_progress", "blocked", "completed", "cancelled")} if "act.status." in t else set()
    used |= {f"dm.status.{s}" for s in ("pending_measurement", "insufficient_data", "measured", "verified", "not_verified", "cancelled")} if "dm.status." in t else set()
    used |= {f"dm.reason.{s}" for s in ("same_kpi", "same_problem", "same_branch", "same_decision_type")} if "dm.reason." in t else set()
    used |= {f"scn.type.{s}" for s in se.TYPES} if "scn.type." in t else set()
    used |= {f"scn.a.{s}" for s in se.ASSUMPTIONS} if "scn.a." in t else set()
    used |= {f"scn.m.{s}" for s in ("revenue", "costs", "profit", "margin_pct")} if "scn.m." in t else set()
used = {k for k in used if not k.endswith(".")}  # dynamic prefixes are expanded above
missing = sorted(used - keys)
ct(f"all {len(used)} keys used by the new pages exist (missing: {missing[:5]})", not missing)
ct("all used keys have both AR and EN", not sorted(used - both))

print(f"\nTOTAL: {P+F} | PASSED: {P} | FAILED: {F}")
sys.exit(0 if F == 0 else 1)
