"""Phase 2.3 engine tests (runnable: python3 test_phase23.py)"""
import json, math, os, sys
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from intelligence_engine import run_quality_checks, detect_signals, build_recommendations, build_executive
from forecast_engine import forecast_metric, build_monthly_series, forecast_company

P = F = 0
def ct(n, c):
    global P, F
    if c: P += 1; print(f"PASS: {n}")
    else: F += 1; print(f"FAIL: {n}")
_i = 0
def R(b, p, s, e, cust=100, rep=30, dep=0, margin=None, profit=None, t=1, inv=10):
    global _i; _i += 1
    return {"id": _i, "branch_id": b, "period": p, "sales": s, "expenses": e, "customers": cust, "invoices": inv,
            "repeat_customers": rep, "deposited": dep, "margin": margin, "profit": profit, "created_at": datetime(2026, 1, 1, 0, 0, t)}
BM = {1: "A", 2: "B"}
codes = lambda ws: [w["code"] for w in ws]

print("[GROUP] data quality — 7 checks")
ct("missing values", "missing_values" in codes(run_quality_checks([], [R(1, "2026-09", 0, 0)], BM)))
ct("duplicates", "duplicate_entries" in codes(run_quality_checks([R(1, "2026-09", 1, 1), R(1, "2026-09", 2, 1)], [], BM)))
ct("invalid negative", "invalid_values" in codes(run_quality_checks([R(1, "2026-09", -5, 1)], [], BM)))
ct("zero customers + sales", "zero_customers_high_sales" in codes(run_quality_checks([], [R(1, "2026-09", 100, 50, cust=0)], BM)))
ct("incorrect margin", "incorrect_margin" in codes(run_quality_checks([R(1, "2026-09", 100, 50, margin=80)], [], BM)))
ct("correct margin not flagged", "incorrect_margin" not in codes(run_quality_checks([R(1, "2026-09", 100, 50, margin=50.0)], [], BM)))
ct("missing branch", "missing_branch_info" in codes(run_quality_checks([R(9, "2026-09", 100, 50)], [], BM)))
ct("inconsistent totals (profit)", "inconsistent_totals" in codes(run_quality_checks([R(1, "2026-09", 100, 50, profit=10)], [], BM)))
ct("inconsistent totals (deposits)", "inconsistent_totals" in codes(run_quality_checks([], [R(1, "2026-09", 100, 50, dep=50)], BM)))
ct("clean data -> no warnings", run_quality_checks([R(1, "2026-09", 100, 50, margin=50.0, profit=50)], [R(1, "2026-09", 100, 50)], BM) == [])

print("[GROUP] risks & opportunities")
sig = lambda cur, prev, **k: detect_signals(cur, prev, BM, period="2026-09", **k)
rc = lambda x: [r["code"] for r in x["risks"]]
ct("declining sales", "declining_sales" in rc(sig([R(1, "2026-09", 80, 10)], [R(1, "2026-08", 100, 10)])))
ct("stable sales -> no decline", "declining_sales" not in rc(sig([R(1, "2026-09", 99, 10)], [R(1, "2026-08", 100, 10)])))
ct("momentum opportunity", "sales_momentum" in [o["code"] for o in sig([R(1, "2026-09", 120, 10)], [R(1, "2026-08", 100, 10)])["opportunities"]])
ct("negative margin critical", any(r["code"] == "negative_margin" and r["severity"] == "critical" for r in sig([R(1, "2026-09", 100, 130)], [])["risks"]))
ct("high expenses", "high_expenses" in rc(sig([R(1, "2026-09", 100, 95)], [])))
ct("margin below target", "margin_below_target" in rc(sig([R(1, "2026-09", 100, 90)], [], company_target_margin=25)))
ct("high inventory", "high_inventory" in rc(sig([R(1, "2026-09", 100, 50)], [], inventory={"value": 100000, "cogs": 30000})))
ct("inventory not evaluated without data", any(n["code"] == "high_inventory" for n in sig([R(1, "2026-09", 100, 50)], [])["not_evaluated"]))
ct("low repeat", "low_repeat" in rc(sig([R(1, "2026-09", 100, 50, cust=100, rep=5)], [])))
ct("repeat not evaluated without customers", any(n["code"] == "low_repeat" for n in sig([R(1, "2026-09", 100, 50, cust=0, rep=0)], [])["not_evaluated"]))
x = sig([R(1, "2026-09", 1000, 500), R(2, "2026-09", 1000, 900)], [])
ct("branch underperformance", "branch_underperformance" in rc(x))
ct("branch margin opportunity with formula", any(o["code"] == "branch_margin_gap" and o["estimated_impact"]["is_estimate"] for o in x["opportunities"]))
bmt = {**BM, ("target", 1): 1000}
ct("branch below target", "branch_below_target" in [r["code"] for r in detect_signals([R(1, "2026-09", 500, 100)], [], bmt, period="p")["risks"]])
ct("missing data risk from quality", "missing_data" in rc(sig([R(1, "2026-09", 100, 50)], [], quality_warnings=[{"code": "missing_values", "severity": "high", "count": 1, "message_ar": "x", "fix": "y"}])))
x = sig([R(1, "2026-09", 80, 10)], [R(1, "2026-08", 100, 10)])["risks"][0]
ct("signal carries rule, KPI, source, severity, impact formula",
   all(x[k] for k in ("method", "metric_id", "source", "severity")) and x["estimated_impact"]["formula"])
ct("signal id deterministic", x["id"] == sig([R(1, "2026-09", 80, 10)], [R(1, "2026-08", 100, 10)])["risks"][0]["id"])
ct("tenant: engine only sees rows given (no branch 2 leakage)", all(r.get("branch_id") in (None, 1) for r in sig([R(1, "2026-09", 80, 10)], [])["risks"]))

print("[GROUP] recommendations")
s2 = sig([R(1, "2026-09", 80, 10)], [R(1, "2026-08", 100, 10)])
recs = build_recommendations(s2, "ALLOW")
need = ("problem_ar", "evidence", "recommendation_ar", "priority", "expected_impact", "confidence", "suggested_action", "success_metric")
ct("all 8 fields present", all(k in recs[0] for k in need))
ct("impact labelled estimate", recs[0]["expected_impact"]["is_estimate"] is True)
blk = build_recommendations(s2, "BLOCK")
ct("BLOCK withholds financial impact", blk[0]["expected_impact"] is None and blk[0]["status"] == "requires_data_first")

print("[GROUP] forecast")
rows = [R(1, f"2026-0{m}", 100000 + m * 5000, 70000) for m in range(1, 7)]
f = forecast_metric(build_monthly_series(rows), "sales", target=140000)
ct("forecast ok with 6 months", f["status"] == "ok" and f["forecast_period"] == "2026-07")
ct("worst <= base <= best", f["worst"]["value"] <= f["base"]["value"] <= f["best"]["value"])
ct("is_estimate + assumptions", f["is_estimate"] and len(f["assumptions"]) == 3)
ct("target gap computed", "target" in f and f["target"]["status"] in ("above", "below"))
ct("insufficient with 2 months", forecast_metric(build_monthly_series(rows[:2]), "sales")["status"] == "insufficient_data")
gap = [R(1, "2026-01", 1, 0), R(1, "2026-02", 1, 0), R(1, "2026-05", 9, 0), R(1, "2026-06", 9, 0)]
ct("gap breaks the series", forecast_metric(build_monthly_series(gap), "sales")["status"] == "insufficient_data")
negp = [R(1, f"2026-0{m}", 100, 100 + m * 10) for m in range(1, 5)]
fp = forecast_metric(build_monthly_series(negp), "profit")
ct("negative profit uses absolute change", fp["status"] == "ok" and fp["change_type"] == "absolute")
out = [R(1, f"2026-0{m}", v, 0) for m, v in zip(range(1, 8), [100, 102, 104, 300, 106, 108, 110])]
ct("outlier flagged not removed", any(w["code"] == "outlier_months" for w in forecast_metric(build_monthly_series(out), "sales")["warnings"]))
fc = forecast_company(rows, [{"id": 1, "name": "A", "target_sales": 0}])
ct("branch forecast present", fc["branches"][0]["branch_name"] == "A")

print("[GROUP] executive assembly")
cur, prev = [R(1, "2026-09", 90000, 60000), R(2, "2026-09", 40000, 45000)], [R(1, "2026-08", 100000, 60000), R(2, "2026-08", 60000, 40000)]
br = [{"id": 1, "name": "A", "target_sales": 100000}, {"id": 2, "name": "B", "target_sales": 80000}]
ex = build_executive(all_rows=cur + prev, current_rows=cur, comparison_rows=prev, branches=br, period="2026-09",
                     comparison_period="2026-08", company_target_margin=25)
for k in ("summary", "revenue_vs_target", "profit_vs_target", "margin", "branch_performance", "risks",
          "opportunities", "recommendations", "data_quality", "forecast"):
    ct(f"section {k}", k in ex)
ct("revenue attainment 72.22%", ex["revenue_vs_target"]["attainment_pct"] == 72.22)
blob = json.dumps(ex, default=str)
ct("no NaN / Infinity anywhere", "NaN" not in blob and "Infinity" not in blob)
empty = build_executive(all_rows=[], current_rows=[], comparison_rows=[], branches=br, period=None, comparison_period=None)
ct("no data -> has_data False, gate BLOCK, no invented numbers",
   empty["has_data"] is False and empty["data_quality"]["gate"] == "BLOCK" and empty["summary"]["net_sales"] is None)
ct("no target -> not_set (not zero)", build_executive(all_rows=cur, current_rows=cur, comparison_rows=[],
   branches=[{"id": 1, "name": "A", "target_sales": 0}, {"id": 2, "name": "B", "target_sales": 0}],
   period="2026-09", comparison_period=None)["revenue_vs_target"]["status"] == "not_set")

print(f"\nTOTAL: {P+F} | PASSED: {P} | FAILED: {F}")
sys.exit(0 if F == 0 else 1)
