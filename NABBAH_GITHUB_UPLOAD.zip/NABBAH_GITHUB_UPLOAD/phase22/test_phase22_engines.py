"""
NABBAH 2.2 — Engine Tests (دائمة، قابلة للتشغيل)
تشمل: Semantic Layer · KPI Engine · Analysis Engines · AI Gateway · Bridge
تُشغّل: python3 test_phase22_engines.py
"""
import sys, os
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.join(_HERE, "..", "phase21"))

from semantic_layer import get_metric_definition, METRICS, metric_envelope, is_sensitive
from kpi_engine import compute_kpis, kpi_value
from analysis_engines import (analyze_by_dimension, compute_variance_analysis,
                              analyze_drivers, analyze_root_cause, compute_financial_impact)
from ai_gateway import (evaluate_quality_gate, MockProvider, build_ai_context,
                        request_ai_analysis)
from platform_bridge import analyze_company_financials, analyze_branches, ai_analyze

passed = failed = 0
def check(name, got, exp):
    global passed, failed
    if got == exp: passed += 1; print(f"PASS: {name}")
    else: failed += 1; print(f"FAIL: {name} — expected {exp}, got {got}")

def ct(name, cond):
    global passed, failed
    if cond: passed += 1; print(f"PASS: {name}")
    else: failed += 1; print(f"FAIL: {name}")


print("=" * 60)
print("  NABBAH 2.2 — ENGINE TEST SUITE")
print("=" * 60)

# ═══ Semantic Layer ═══
print("\n[GROUP] Semantic Layer")
ct("25 metric definitions registered", len(METRICS) >= 25)
ct("net_sales has definition", get_metric_definition("net_sales") is not None)
ct("unknown metric returns None", get_metric_definition("fake_metric") is None)
ct("payroll_pct marked sensitive", is_sensitive("payroll_pct") is True)
ct("net_sales not sensitive", is_sensitive("net_sales") is False)
env = metric_envelope("net_sales", 92000, period="1/2026")
required = ["metric_id","name","definition","formula","value","currency","period",
            "source","calculation_version","data_quality","timestamp"]
ct("envelope has 11 required fields", all(k in env for k in required))
# التعريف موحّد بغض النظر عن الطالب
d1 = get_metric_definition("gross_margin")
d2 = get_metric_definition("gross_margin")
ct("same metric = same definition (canonical)", d1 == d2)

# ═══ KPI Engine ═══
print("\n[GROUP] KPI Engine")
raw = {"gross_sales":100000,"discounts":5000,"returns":3000,"transactions":1000,
       "cogs":50000,"operating_expenses":30000,"payroll":15000,"rent":8000,
       "marketing":4000,"depreciation":2000,"interest":1000,"tax":1500,
       "previous_net_sales":85000}
k = compute_kpis(raw, period="1/2026", data_quality="good")
check("Net Sales = 92000.00", k["net_sales"]["value_decimal"], "92000.00")
check("Gross Profit = 42000.00", k["gross_profit"]["value_decimal"], "42000.00")
check("Gross Margin = 45.65", k["gross_margin"]["value_decimal"], "45.65")
check("EBIT = 12000.00", k["ebit"]["value_decimal"], "12000.00")
check("EBITDA = 14000.00", k["ebitda"]["value_decimal"], "14000.00")
check("PBT = 11000.00", k["pbt"]["value_decimal"], "11000.00")
check("Net Profit = 9500.00", k["net_profit"]["value_decimal"], "9500.00")
check("AOV = 92.00", k["aov"]["value_decimal"], "92.00")
check("Expense Ratio = 32.61", k["expense_ratio"]["value_decimal"], "32.61")
check("COGS% = 54.35", k["cogs_pct"]["value_decimal"], "54.35")
check("Return% = 3.00", k["return_pct"]["value_decimal"], "3.00")
check("Discount% = 5.00", k["discount_pct"]["value_decimal"], "5.00")
check("Growth = 8.24", k["growth"]["value_decimal"], "8.24")
# حالات حدّية
k0 = compute_kpis({"gross_sales":0})
ct("zero sales: no crash, margin None", k0["gross_margin"]["value"] is None)
kn = compute_kpis({"gross_sales":None})
ct("null input: net_sales None", kn["net_sales"]["value"] is None)
knp = compute_kpis({"gross_sales":1000,"cogs":1500})
check("negative gross profit preserved", knp["gross_profit"]["value_decimal"], "-500.00")
ct("no NaN in any KPI", all(str(v.get("value")) != "nan" for v in k.values()))
ct("no Infinity in any KPI", all("inf" not in str(v.get("value")).lower() for v in k.values()))

# ═══ Dimension Analysis ═══
print("\n[GROUP] Dimension Analysis")
dim = analyze_by_dimension([
    {"branch":"Riyadh","gross_sales":60000,"transactions":600},
    {"branch":"Jeddah","gross_sales":40000,"transactions":400},
], "branch", "net_sales")
ct("dimension analysis works", dim["has_data"])
check("contribution 60%", dim["items"][0]["contribution_pct"], 60.0)
dim_empty = analyze_by_dimension([], "branch")
ct("empty records: no crash", dim_empty["has_data"] is False)
dim_bad = analyze_by_dimension([{"x":1}], "invalid_dim")
ct("invalid dimension rejected", "error" in dim_bad)

# ═══ Variance Engine ═══
print("\n[GROUP] Variance Engine")
v = compute_variance_analysis(92000, 85000, "net_sales", comparison_type="previous_period")
check("absolute variance = 7000", v["absolute_variance"], 7000.0)
check("percentage variance = 8.24", v["percentage_variance"], 8.24)
ct("favorable=True (sales up)", v["favorable"] is True)
v_exp = compute_variance_analysis(90000, 100000, "operating_expenses")
ct("expense down = favorable", v_exp["favorable"] is True)
vz = compute_variance_analysis(100, 0, "net_sales")
ct("zero baseline: pct None (no Infinity)", vz["percentage_variance"] is None)
vm = compute_variance_analysis(None, 100, "net_sales")
ct("missing data: variance None", vm["absolute_variance"] is None)

# ═══ Driver Analysis ═══
print("\n[GROUP] Driver Analysis")
cur = {"gross_sales":92000,"transactions":900}
prev = {"gross_sales":100000,"transactions":1000}
dr = analyze_drivers(cur, prev, "net_sales")
ct("observed fact calculated", dr["observed_fact"]["change"] is not None)
ct("drivers identified", len(dr["drivers"]) > 0)
calc = [d for d in dr["drivers"] if d["type"] == "calculated_contribution"]
ct("contribution calculated for tx/aov", len(calc) >= 1)
unavail = [d for d in dr["drivers"] if d["contribution"] == "unavailable"]
ct("missing driver data -> 'unavailable' (no fabrication)", len(unavail) >= 1)
ct("causation disclaimer present", "سببية" in dr["causation_disclaimer"])
ct("all drivers have required fields",
   all(all(f in d for f in ["driver_id","driver_name","direction","contribution",
                             "evidence","data_quality","confidence","explanation"])
       for d in dr["drivers"]))

# ═══ Root Cause ═══
print("\n[GROUP] Root Cause Engine")
rc = analyze_root_cause(dr, data_quality="good")
ct("FACT section exists", len(rc["FACT"]) > 0)
ct("INTERPRETATION separate", "INTERPRETATION" in rc)
ct("HYPOTHESIS separate", "HYPOTHESIS" in rc)
ct("RECOMMENDATION separate", "RECOMMENDATION" in rc)
ct("hypotheses marked unverified",
   all(h.get("status") == "unverified" for h in rc["HYPOTHESIS"]) if rc["HYPOTHESIS"] else True)
rc_weak = analyze_root_cause({"observed_fact":{},"drivers":[]}, data_quality="fail")
ct("insufficient evidence detected", rc_weak["root_cause"]["status"] == "insufficient_evidence")
ct("required data listed on insufficiency", "required_data" in rc_weak["root_cause"])
rc_lowq = analyze_root_cause(dr, data_quality="fail")
ct("low quality blocks root cause", rc_lowq["evidence_sufficient"] is False)

# ═══ Financial Impact ═══
print("\n[GROUP] Financial Impact Engine")
imp = compute_financial_impact(dr, currency="SAR")
ct("impacts calculated", imp["calculable_count"] > 0)
ct("uncalculable marked", imp["unavailable_count"] >= 0)
check("currency preserved", imp["currency"], "SAR")
ct("all impacts have required fields",
   all(all(f in i for f in ["impact_type","value","currency","period","formula",
                             "source","calculation_version","data_quality","confidence"])
       for i in imp["impacts"]))
ct("no NaN in impacts", all("nan" not in str(i.get("value")).lower() for i in imp["impacts"]))

# ═══ Quality Gate ═══
print("\n[GROUP] Data Quality Gate")
g_allow = evaluate_quality_gate({"overall_score":90,"status":"pass","main_causes":[]})
check("high quality -> ALLOW", g_allow["status"], "ALLOW")
g_qual = evaluate_quality_gate({"overall_score":65,"status":"warning",
                                 "main_causes":[{"explanation":"gap","fix":"complete data"}]})
check("medium quality -> QUALIFY", g_qual["status"], "QUALIFY")
ct("QUALIFY includes qualification text", "qualification" in g_qual)
g_block = evaluate_quality_gate({"overall_score":30,"status":"fail","has_critical_fail":True,
                                  "main_causes":[{"explanation":"critical","fix":"fix data"}]})
check("failed quality -> BLOCK", g_block["status"], "BLOCK")
ct("BLOCK prevents financial recommendation", g_block["allow_financial_recommendation"] is False)
ct("BLOCK lists required data", len(g_block["required_data"]) > 0)
g_none = evaluate_quality_gate(None)
check("no trust report -> BLOCK", g_none["status"], "BLOCK")

# ═══ AI Gateway ═══
print("\n[GROUP] AI Gateway")
mock = MockProvider("FACTS: sales 92000\nINTERPRETATION: growth\nHYPOTHESES: seasonal\nRECOMMENDATIONS: continue\nDATA GAPS: product data")
res_block = request_ai_analysis(mock, {}, "why?",
                                 trust_report={"overall_score":20,"status":"fail",
                                               "has_critical_fail":True,"main_causes":[]})
ct("BLOCK -> AI not called", res_block["ai_called"] is False)
ct("BLOCK -> no recommendations", len(res_block["response"]["RECOMMENDATIONS"]) == 0)
res_ok = request_ai_analysis(mock, {"verified_metrics":{"net_sales":{"value":92000}}}, "why?",
                              trust_report={"overall_score":90,"status":"pass","main_causes":[]})
ct("ALLOW -> AI called", res_ok["ai_called"] is True)
ct("response parsed into sections", len(res_ok["response"]["FACTS"]) > 0)
ct("contract forbids inventing numbers", "لا تحسب رقماً بنفسك" in mock.last_prompt)
ct("contract enforces 5 sections",
   all(s in mock.last_prompt for s in ["FACTS","INTERPRETATION","HYPOTHESES","RECOMMENDATIONS","DATA GAPS"]))
res_q = request_ai_analysis(mock, {}, "", trust_report={"overall_score":65,"status":"warning","main_causes":[]})
ct("QUALIFY adds warning to prompt", "تنويه" in mock.last_prompt)
ct("provider is replaceable", mock.name == "mock")
ctx = build_ai_context(kpis={"net_sales":{"has_data":True,"name":"Net Sales","value":92000,
                                            "unit":"currency","formula":"x"}},
                        trust_report={"overall_score":85,"status":"pass","main_causes":[]})
ct("context carries verified metrics only", "net_sales" in ctx["verified_metrics"])
ct("context carries data quality", ctx["data_quality"]["score"] == 85)

# ═══ Platform Bridge (Integration) ═══
print("\n[GROUP] Platform Bridge Integration")
class _Entry:
    def __init__(s, sales, invoices, expenses, discounts=0):
        s.sales=sales; s.invoices=invoices; s.expenses=expenses; s.discounts=discounts

entries = [_Entry(60000,600,40000), _Entry(40000,400,28000)]
prev_e = [_Entry(55000,550,38000), _Entry(38000,380,26000)]
mdata = {"تكلفة البضاعة المباعة":50000, "الرواتب":15000, "الإيجار":8000}

res = analyze_company_financials(entries, module_data=mdata, previous_entries=prev_e,
                                  period="1/2026", user_role="owner", company_name="TestCo")
ct("bridge computes KPIs", res["kpis"]["net_sales"]["has_data"])
check("gross sales aggregated = 100000", res["kpis"]["gross_sales"]["value"], 100000)
ct("trust report included", "overall_score" in res["trust"])
ct("quality gate included", res["gate"]["status"] in ("ALLOW","QUALIFY","BLOCK"))
ct("drivers computed with previous period", res["drivers"] is not None)
ct("root cause computed", res["root_cause"] is not None)
ct("financial impact computed", res["financial_impact"] is not None)

# RBAC: sensitive fields
res_staff = analyze_company_financials(entries, module_data=mdata, user_role="staff")
pay_staff = res_staff["kpis"].get("payroll_pct", {})
ct("staff: payroll_pct restricted", pay_staff.get("value") is None and pay_staff.get("restricted") is True)
res_owner = analyze_company_financials(entries, module_data=mdata, user_role="owner")
ct("owner: payroll_pct visible", res_owner["kpis"]["payroll_pct"].get("restricted") is not True)

# Branch analysis
br = analyze_branches([{"branch":"Riyadh","gross_sales":60000,"transactions":600},
                       {"branch":"Jeddah","gross_sales":40000,"transactions":400}])
ct("branch analysis works", br["has_data"])
check("branches ranked correctly", br["items"][0]["label"], "Riyadh")

# AI through bridge
def _fake_gemini(prompt, company=None, lang="ar"):
    return "FACTS: sales 100000\nRECOMMENDATIONS: continue"
ai_res = ai_analyze(_fake_gemini, res, "how is performance?")
ct("AI called through gate", "gate" in ai_res)
ct("AI response structured", "FACTS" in ai_res["response"])

print("\n" + "=" * 60)
print(f"  TOTAL: {passed + failed} | PASSED: {passed} | FAILED: {failed}")
print("=" * 60)
sys.exit(0 if failed == 0 else 1)
