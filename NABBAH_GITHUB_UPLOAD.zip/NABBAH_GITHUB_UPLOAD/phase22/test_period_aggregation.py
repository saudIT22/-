"""Remediation tests — period-aware aggregation (runnable: python3 test_period_aggregation.py)"""
import os, sys
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from period_aggregation import split_by_period, parse_period
from platform_bridge import analyze_company_financials

P = F = 0
def ct(name, cond):
    global P, F
    if cond: P += 1; print(f"PASS: {name}")
    else: F += 1; print(f"FAIL: {name}")

class E:
    def __init__(self, branch_id, period, sales, invoices=100, expenses=0, ts=1):
        self.branch_id, self.period, self.sales = branch_id, period, sales
        self.invoices, self.expenses, self.discounts = invoices, expenses, 0
        self.created_at = datetime(2026, 1, 1, 0, 0, ts)

print("[GROUP] period parsing")
ct("YYYY-MM parsed", parse_period("2026-09") == (2026, 9))
ct("M/YYYY parsed", parse_period("9/2026") == (2026, 9))
ct("month 13 rejected", parse_period("2026-13") is None)
ct("free text rejected", parse_period("September") is None)
ct("None rejected", parse_period(None) is None)

print("[GROUP] current vs previous month")
s = split_by_period([E(1, "2026-09", 100), E(1, "2026-08", 80)])
ct("current = 2026-09", s["current_period"] == "2026-09")
ct("comparison = 2026-08", s["comparison_period"] == "2026-08")
ct("has comparison", s["has_comparison"] is True)

print("[GROUP] no comparison period")
s = split_by_period([E(1, "2026-09", 100), E(1, "2026-06", 50)])
ct("gap month is NOT used as comparison", s["comparison_entries"] == [])
ct("has_comparison False", s["has_comparison"] is False)
ct("gap reported", any(g["missing"] == "comparison_period_data" for g in s["data_gaps"]))
r = analyze_company_financials(s["current_entries"], previous_entries=s["comparison_entries"] or None,
                               period=s["current_period"], period_gaps=s["data_gaps"])
ct("growth NOT calculated without comparison", r["kpis"]["growth"]["value"] is None)
ct("drivers NOT calculated without comparison", r["drivers"] is None)

print("[GROUP] multiple records in one period")
s = split_by_period([E(1, "2026-09", 100, ts=1), E(1, "2026-09", 130, ts=5)])
ct("same branch: one row kept", len(s["current_entries"]) == 1)
ct("same branch: latest submission wins", s["current_entries"][0].sales == 130)
ct("superseded counted", s["superseded_duplicates"] == 1)

print("[GROUP] multiple branches")
s = split_by_period([E(1, "2026-09", 100), E(2, "2026-09", 60), E(1, "2026-08", 90), E(2, "2026-08", 40)])
r = analyze_company_financials(s["current_entries"], previous_entries=s["comparison_entries"],
                               period=s["current_period"])
ct("branches summed: gross 160", r["kpis"]["gross_sales"]["value"] == 160)
ct("growth = (160-130)/130 = 23.08%", r["kpis"]["growth"]["value_decimal"] == "23.08")

print("[GROUP] missing / bad dates")
s = split_by_period([E(1, "2026-09", 100), E(2, "", 999), E(3, None, 999), E(4, "abc", 999)])
ct("3 unparseable rows excluded", s["excluded_unparseable"] == 3)
ct("excluded rows not aggregated", sum(e.sales for e in s["current_entries"]) == 100)
ct("gap reported for bad dates", any(g["missing"] == "valid_period" for g in s["data_gaps"]))
s = split_by_period([E(1, None, 100)])
ct("no usable period -> no current period", s["current_period"] is None)

print("[GROUP] year boundary + explicit period")
s = split_by_period([E(1, "2026-01", 100), E(1, "2025-12", 90)])
ct("Jan compares to previous Dec", s["comparison_period"] == "2025-12" and s["has_comparison"])
s = split_by_period([E(1, "2026-09", 100), E(1, "2026-08", 80)], current_period="2026-08")
ct("explicit period honoured", s["current_period"] == "2026-08")
s = split_by_period([E(1, "2026-09", 100)], current_period="not-a-period")
ct("invalid requested period -> gap, no data", s["current_entries"] == [] and s["data_gaps"])

print("[GROUP] missing stays missing")
r = analyze_company_financials([], user_role="owner")
ct("no entries -> net_sales None (not 0)", r["kpis"]["net_sales"]["value"] is None)

print(f"\nTOTAL: {P+F} | PASSED: {P} | FAILED: {F}")
sys.exit(0 if F == 0 else 1)
