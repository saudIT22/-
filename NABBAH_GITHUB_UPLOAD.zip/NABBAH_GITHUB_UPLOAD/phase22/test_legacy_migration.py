"""Option B — production compute_company_metrics vs the original legacy code.
Executes the REAL function extracted from main.py (no FastAPI needed).
Run: python3 test_legacy_migration.py"""
import ast, os, random, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from legacy_adapters import central_company_metrics
from nabbah_finance import LEGACY_COMPATIBLE as L, ACCOUNTING_HALF_UP as H
P = F = 0
def ct(name, cond):
    global P, F
    if cond: P += 1; print(f"PASS: {name}")
    else: F += 1; print(f"FAIL: {name}")

# ORACLE: original function, verbatim from main.py before Phase 2.2
def original(sales, invoices, customers, repeat_customers, expenses, prev_sales=None):
    profit = round(sales - expenses, 2)
    margin = round((profit / sales) * 100, 1) if sales > 0 else 0
    avg_invoice = round(sales / invoices, 1) if invoices > 0 else 0
    repeat_rate = round((repeat_customers / customers) * 100, 1) if customers > 0 else 0
    has_prev = bool(prev_sales and prev_sales > 0)
    growth = round(((sales - prev_sales) / prev_sales) * 100, 1) if has_prev else 0
    score = 0
    if margin >= 25: score += 35
    elif margin >= 18: score += 28
    elif margin >= 12: score += 20
    elif margin >= 6: score += 11
    elif margin > 0: score += 5
    if not has_prev: score += 18
    elif growth >= 10: score += 30
    elif growth >= 3: score += 23
    elif growth >= 0: score += 16
    elif growth >= -8: score += 8
    elif growth >= -20: score += 3
    if repeat_rate >= 40: score += 20
    elif repeat_rate >= 25: score += 14
    elif repeat_rate >= 15: score += 9
    elif repeat_rate > 0: score += 4
    if profit > 0: score += 15
    score = min(score, 100)
    return {"profit": profit, "margin": margin, "avg_invoice": avg_invoice,
            "repeat_rate": repeat_rate, "growth": growth, "branch_score": score}

# Load the PRODUCTION function from main.py
MAIN = os.path.join(HERE, "..", "main.py")
tree = ast.parse(open(MAIN, encoding="utf-8").read())
wanted = [n for n in tree.body if (isinstance(n, ast.FunctionDef) and n.name in ("_legacy_adapter", "compute_company_metrics"))
          or (isinstance(n, ast.Assign) and any(getattr(t, "id", "") == "_LEGACY_ADAPTER" for t in n.targets))]
ns = {"__file__": os.path.abspath(MAIN)}
exec(compile(ast.Module(body=wanted, type_ignores=[]), MAIN, "exec"), ns)
prod = ns["compute_company_metrics"]

random.seed(99); cases = []
for _ in range(30000):
    s = random.choice([0, random.randint(1, 9_000_000), round(random.uniform(0.01, 900000), 2)])
    e = random.choice([random.randint(0, 9_000_000), round(random.uniform(0, 900000), 2)])
    inv = random.choice([0, random.randint(1, 50000)]); cu = random.choice([0, random.randint(1, 50000)])
    r = random.randint(0, cu) if cu else 0; p = random.choice([None, 0, random.randint(1, 9_000_000)])
    cases.append((s, inv, cu, r, e, p))
ties = [(400, 1, 1, 0, 351, None), (449, 1, 1, 0, 0, 400), (0.125, 1, 1, 0, 0, None), (4005176, 224, 1, 0, 0, None)]
cases += ties

print("[GROUP] production function uses the engine")
ct("adapter loaded by production code", ns["_legacy_adapter"]() is not None)
ct("inline fallback still present in main.py", "profit = round(sales - expenses, 2)" in open(MAIN, encoding="utf-8").read())

print("[GROUP] production output identical to original (30,004 cases incl. ties)")
diff = sum(prod(*c) != original(*c) for c in cases)
ct(f"0 differences in all 6 fields incl. branch_score (found {diff})", diff == 0)

print("[GROUP] fallback path identical to original")
ns["_LEGACY_ADAPTER"] = False
diff_fb = sum(prod(*c) != original(*c) for c in cases[:5000])
ct(f"engine unavailable -> identical output (found {diff_fb})", diff_fb == 0)
ns["_LEGACY_ADAPTER"] = None

print("[GROUP] ACCOUNTING_HALF_UP differs only where expected (not enabled)")
t = central_company_metrics(400, 1, 1, 0, 351, None, H)
ct("margin 12.25% tie: HALF_UP=12.3 vs production 12.2", t["margin"] == 12.3 and prod(400, 1, 1, 0, 351, None)["margin"] == 12.2)
ct("HALF_UP is opt-in only (adapter default is LEGACY)", central_company_metrics(1, 1, 1, 0, 0)["rounding_mode"] == L)

print(f"\nTOTAL: {P+F} | PASSED: {P} | FAILED: {F}")
sys.exit(0 if F == 0 else 1)
