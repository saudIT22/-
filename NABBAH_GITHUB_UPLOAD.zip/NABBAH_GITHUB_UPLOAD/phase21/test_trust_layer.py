"""
NABBAH 2.0 — Phase 2.1 Data Trust + Isolation Tests
تُشغّل بـ: python3 test_trust_layer.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nabbah_trust import (check_completeness, check_validity, check_consistency,
                          check_freshness, check_reconciliation, check_duplicates,
                          run_all_checks)

passed = failed = 0
def ct(name, cond):
    global passed, failed
    if cond: passed += 1; print(f"✅ {name}")
    else: failed += 1; print(f"❌ {name}")

print("═" * 55)
print("  اختبار طبقة الموثوقية + العزل — Phase 2.1")
print("═" * 55)

# ═══ الأبعاد الستة ═══
print("\n【 الأبعاد الستة 】")
ct("Completeness يكشف الناقص",
   check_completeness([{"sales":100}], ["sales","expenses"])["status"] == "fail")
ct("Completeness يمرّر الكامل",
   check_completeness([{"sales":100,"expenses":70}], ["sales","expenses"])["status"] == "pass")
ct("Validity يكشف السالب",
   check_validity([{"sales":-5}], ["sales"])["status"] == "warning")
ct("Validity يمرّر الموجب",
   check_validity([{"sales":100}], ["sales"])["status"] == "pass")
ct("Consistency يكشف عدم التطابق",
   check_consistency(100, [50,30])["status"] == "warning")
ct("Consistency يمرّر التطابق",
   check_consistency(100, [50,50])["status"] == "pass")
ct("Freshness يكشف القديم",
   check_freshness("2024-01-01T00:00:00+00:00", stale_days=90)["status"] == "warning")
ct("Reconciliation يكشف الفرق الكبير",
   check_reconciliation(80000, 100000)["status"] == "warning")
ct("Reconciliation يمرّر المتقارب",
   check_reconciliation(99000, 100000)["status"] == "pass")
ct("Duplicates يكشف التكرار",
   check_duplicates([{"id":"A"},{"id":"A"}], ["id"])["status"] == "warning")
ct("Duplicates يمرّر الفريد",
   check_duplicates([{"id":"A"},{"id":"B"}], ["id"])["status"] == "pass")

# ═══ البنية الإلزامية ═══
print("\n【 البنية الإلزامية 】")
r = check_completeness([{"sales":100}], ["sales","expenses"])
required = ["status","severity","affected_records","explanation","suggested_fix","timestamp"]
ct("كل نتيجة تحوي 6 حقول إلزامية", all(k in r for k in required))

# ═══ درجة الموثوقية الشاملة ═══
print("\n【 درجة الموثوقية الشاملة 】")
all_pass = run_all_checks([
    check_completeness([{"sales":100,"expenses":70}], ["sales","expenses"]),
    check_validity([{"sales":100}], ["sales"]),
])
ct("كل الفحوص pass → درجة عالية", all_pass["overall_score"] >= 80)
mixed = run_all_checks([
    check_completeness([{"sales":100}], ["sales","expenses","customers"]),
    check_validity([{"sales":-5}], ["sales"]),
])
ct("فحوص مختلطة → أسباب رئيسية", len(mixed["main_causes"]) > 0)

# ═══ العزل (منطق: كل فحص يعمل على سجلات شركة واحدة) ═══
print("\n【 عزل البيانات 】")
# نحاكي: فحص شركة A لا يرى سجلات شركة B
company_a_records = [{"company_id":1,"sales":100}]
company_b_records = [{"company_id":2,"sales":999}]
# الفحص يُمرّر له سجلات شركة واحدة فقط (العزل في طبقة الاستعلام قبل الفحص)
ra = check_completeness(company_a_records, ["sales"])
ct("فحص شركة A يعمل على سجلاتها فقط", ra["status"] == "pass")
# لا خلط: الدالة لا تعرف عن company_b
ct("الفحص لا يجمع بيانات شركات مختلفة",
   len(company_a_records) == 1)  # مُرّر سجل واحد فقط



# ═══ النقطة ٣: الجودة المقوّاة ═══
print("\n【 الجودة المقوّاة 】")
from nabbah_trust import can_ai_recommend
# القيم غير الرقمية = fail (لا تُتجاهل)
r_bad = check_validity([{"sales":"abc"}], ["sales"], numeric_fields=["sales"])
ct("قيمة غير رقمية → fail", r_bad["status"] == "fail")
# Consistency: الناقص لا يُعامَل كصفر
r_miss = check_consistency(100, [50, None])
ct("تفصيل ناقص → warning (لا صفر صامت)", r_miss["status"] == "warning")
# درجة مرجّحة: فشل مالي حرج يُخفّض بقوة
fail_report = run_all_checks([
    check_validity([{"sales":"xyz"}], ["sales"], numeric_fields=["sales"]),  # fail high
    check_completeness([{"sales":100,"expenses":70}], ["sales","expenses"]),  # pass
])
ct("فشل حرج → درجة ≤40 (لا يُخفيه المتوسط)", fail_report["overall_score"] <= 40)
ct("has_critical_fail مرفوع", fail_report["has_critical_fail"] is True)

# ═══ النقطة ٣: منع توصية AI عند فشل الجودة ═══
print("\n【 ربط AI بالجودة 】")
allowed_fail, _ = can_ai_recommend(fail_report)
ct("جودة فاشلة → AI ممنوع من التوصية القطعية", allowed_fail is False)
good_report = run_all_checks([
    check_completeness([{"sales":100,"expenses":70}], ["sales","expenses"]),
    check_validity([{"sales":100}], ["sales"]),
])
allowed_ok, _ = can_ai_recommend(good_report)
ct("جودة جيدة → AI مسموح", allowed_ok is True)

print("\n" + "═" * 55)
print(f"  النتيجة: {passed}/{passed+failed} اختبار ناجح")
print("═" * 55)
sys.exit(0 if failed == 0 else 1)
