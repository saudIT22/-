"""
NABBAH 2.0 — Phase 2.1 Financial Engine Tests
اختبارات محرك الحسابات + الحالات الحدّية الـ15 المطلوبة.
تُشغّل بـ: python3 test_finance_engine.py (بلا pytest — قابلة للتشغيل في أي بيئة)
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nabbah_finance import (compute_sales, compute_profit, compute_expenses,
                            compute_variance, to_decimal, safe_divide, round_money)
from decimal import Decimal

passed = failed = 0
def check(name, got, exp):
    global passed, failed
    if got == exp:
        passed += 1; print(f"✅ {name}")
    else:
        failed += 1; print(f"❌ {name}: توقّع {exp} حصل {got}")

def check_true(name, cond):
    global passed, failed
    if cond: passed += 1; print(f"✅ {name}")
    else: failed += 1; print(f"❌ {name}")


print("═" * 55)
print("  اختبار محرك الحسابات المالية — Phase 2.1")
print("═" * 55)

# ═══ المثال المرجعي المطلوب ═══
print("\n【 المثال المرجعي (Decimal) 】")
s = compute_sales(100000, discounts=5000, returns=3000, transactions=1000)
p = compute_profit(92000, cogs=50000)
check("Net Sales = 92000", s["net_sales"]["value_decimal"], "92000.00")
check("Gross Profit = 42000", p["gross_profit"]["value_decimal"], "42000.00")
check("Gross Margin = 45.65%", p["gross_margin"]["value_decimal"], "45.65")

# ═══ الحالات الحدّية الـ15 ═══
print("\n【 الحالات الحدّية (15) 】")

# 1. Sales = 0
s0 = compute_sales(0)
check_true("① Sales=0: لا انهيار", s0["net_sales"]["value"] == 0)

# 2. COGS = 0
p_cogs0 = compute_profit(1000, cogs=0)
check("② COGS=0: Gross Profit=1000", p_cogs0["gross_profit"]["value_decimal"], "1000.00")

# 3. Negative profit
p_neg = compute_profit(1000, cogs=1500)
check("③ ربح سالب = -500", p_neg["gross_profit"]["value_decimal"], "-500.00")

# 4. Negative margin
check_true("④ هامش سالب", to_decimal(p_neg["gross_margin"]["value_decimal"]) < 0)

# 5. Missing data (None)
p_none = compute_profit(None, cogs=500)
check_true("⑤ بيانات ناقصة → has_data=False", p_none["gross_profit"]["has_data"] is False)

# 6. Null values
s_null = compute_sales(None)
check_true("⑥ Null → net_sales=None", s_null["net_sales"]["value"] is None)

# 7. Returned invoice (مرتجعات)
s_ret = compute_sales(10000, returns=2000)
check("⑦ مرتجعات: net=8000", s_ret["net_sales"]["value_decimal"], "8000.00")

# 8. Discount > sales
s_disc = compute_sales(1000, discounts=1500)
check("⑧ خصم>مبيعات: net=-500", s_disc["net_sales"]["value_decimal"], "-500.00")

# 9. VAT منفصل
s_vat = compute_sales(10000, vat=1500)
check_true("⑨ VAT منفصل عن net", s_vat["vat"]["value"] == 1500 and s_vat["net_sales"]["value"] == 10000)

# 10. Duplicate invoice (يُعالَج في trust layer — هنا نتأكد الحساب لا ينهار)
check_true("⑩ تكرار: الحساب مستقل", compute_sales(5000)["gross_sales"]["value"] == 5000)

# 11. Different currencies (المحرك يحمل العملة)
s_usd = compute_sales(1000, currency="USD")
check("⑪ عملة مختلفة", s_usd["net_sales"]["currency"], "USD")

# 12. Different periods (المحرك يحمل الفترة)
s_per = compute_sales(1000, period="1/2026")
check("⑫ فترة محفوظة", s_per["net_sales"]["period"], "1/2026")

# 13. Branch wrong company → (يُعالَج في العزل — هنا نتأكد الحساب لا يخلط)
check_true("⑬ حساب معزول لكل استدعاء", compute_sales(100)["gross_sales"]["value"] == 100)

# 14. Invalid negative (يُقبل مع علم — لا انهيار)
check_true("⑭ قيمة سالبة لا تنهار", compute_profit(-100, cogs=50)["gross_profit"]["value"] is not None)

# 15. Division by zero
check_true("⑮ قسمة على صفر → None (لا Infinity)", safe_divide(100, 0) is None)

# ═══ منع NaN/Infinity ═══
print("\n【 منع NaN/Infinity 】")
check_true("لا Infinity من القسمة", safe_divide(1, 0) is None)
check_true("لا NaN من نص فاسد", to_decimal("abc") is None)
check_true("net margin عند sales=0 → None", compute_profit(0, cogs=0)["net_margin"]["value"] is None)

# ═══ تنظيف الأرقام ═══
print("\n【 تنظيف الأرقام 】")
check("فواصل: 120,000 → 120000", str(to_decimal("120,000")), "120000")
check("نسبة: 25% → 25", str(to_decimal("25%")), "25")
check("عملة: 1000 ريال → 1000", str(to_decimal("1000 ريال")), "1000")

# ═══ الانحراف (Variance) ═══
print("\n【 تحليل الانحراف 】")
v_rev = compute_variance(100000, 110000, metric_type="revenue")
check_true("إيراد فوق الموازنة = مواتٍ", v_rev["favorable"] is True)
v_exp = compute_variance(100000, 90000, metric_type="expense")
check_true("مصروف أقل من الموازنة = مواتٍ", v_exp["favorable"] is True)
v_exp_bad = compute_variance(100000, 120000, metric_type="expense")
check_true("مصروف أعلى = غير مواتٍ", v_exp_bad["favorable"] is False)

# ═══ التوثيق الإلزامي ═══
print("\n【 التوثيق الإلزامي لكل نتيجة 】")
required = ["metric","value","currency","period","source","method","data_quality","has_data","calculated_at"]
sample = compute_sales(1000, period="1/2026")["net_sales"]
check_true("كل نتيجة موثّقة (9 حقول)", all(k in sample for k in required))



# ═══ تسلسل الربح الكامل (النقطة ١) ═══
print("\n【 تسلسل الربح الكامل 】")
pf = compute_profit(92000, cogs=50000, operating_expenses=30000, depreciation=2000, interest=1000, tax=1500)
check("EBIT (Operating Profit) = 12000", pf["operating_profit"]["value_decimal"], "12000.00")
check("EBITDA = 14000", pf["ebitda"]["value_decimal"], "14000.00")
check("PBT = 11000", pf["profit_before_tax"]["value_decimal"], "11000.00")
check("Net Profit = 9500 (بكل المكوّنات)", pf["net_profit"]["value_decimal"], "9500.00")

# Net Profit = None عند نقص المكوّنات (لا يُعرض ربح غير مكتمل)
pf_partial = compute_profit(92000, cogs=50000, operating_expenses=30000)
check_true("Net Profit = None بلا فائدة/ضريبة", pf_partial["net_profit"]["value"] is None)
check_true("EBIT يظهر رغم نقص الضريبة", pf_partial["operating_profit"]["value"] == 12000)
check_true("EBITDA = None بلا إهلاك", pf_partial["ebitda"]["value"] is None)

# ═══ دقة Decimal (النقطة ٢) ═══
print("\n【 دقة Decimal في JSON 】")
big = compute_sales(999999999.99)
check("مبلغ كبير: value_decimal دقيق", big["gross_sales"]["value_decimal"], "999999999.99")
small = compute_profit(100, cogs=33)
check_true("عشري: value_decimal نصّي دقيق", small["gross_profit"]["value_decimal"] == "67.00")
check_true("عدد صحيح: value = int", isinstance(compute_sales(1000)["gross_sales"]["value"], int))

print("\n" + "═" * 55)
print(f"  النتيجة: {passed}/{passed+failed} اختبار ناجح")
print("═" * 55)
sys.exit(0 if failed == 0 else 1)
