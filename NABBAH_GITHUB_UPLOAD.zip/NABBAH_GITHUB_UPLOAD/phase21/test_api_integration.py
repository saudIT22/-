"""
NABBAH 2.0 — Phase 2.1 API Integration Tests (النقطة ٤)
تثبت جاهزية الدمج عبر API الفعلي.

⚠️ تتطلب: pytest + fastapi + المحرك مدموجاً في main.py.
لا تعمل قبل الدمج (Phase 2.2) — هذا مقصود ومُوثّق.
للتشغيل بعد الدمج: pytest test_api_integration.py -v

الحالة الآن: NOT EXECUTABLE (المحرك لم يُدمَج بعد + لا مكتبات بيئياً).
لا تُحسب PASS حتى تُشغّل فعلياً على CI بعد الدمج.
"""
import pytest


# ═══ هذه الاختبارات تُفعّل بعد دمج المحرك في main.py (Phase 2.2) ═══

@pytest.mark.skip(reason="يتطلب دمج المحرك في main.py — Phase 2.2")
def test_financial_endpoint_uses_engine(client):
    """كل endpoint مالي يستخدم المحرك الجديد (نفس الأرقام)."""
    # بعد الدمج: نقارن ناتج /company/financial-overview مع compute_profit
    pass


@pytest.mark.skip(reason="يتطلب دمج المحرك — Phase 2.2")
def test_tenant_isolation_financial(client):
    """شركة A لا ترى أرقام شركة B عبر API المالي."""
    pass


@pytest.mark.skip(reason="يتطلب دمج المحرك — Phase 2.2")
def test_ui_matches_engine(client):
    """النتائج في الواجهة مطابقة للمحرك بالضبط."""
    pass


@pytest.mark.skip(reason="يتطلب دمج المحرك — Phase 2.2")
def test_import_passes_quality_checks(client):
    """بيانات Excel/CSV المستوردة تمر عبر فحوص الجودة."""
    pass


@pytest.mark.skip(reason="يتطلب دمج المحرك — Phase 2.2")
def test_old_reports_still_correct(client):
    """التقارير القديمة تعطي نفس النتائج بعد الدمج (regression)."""
    pass


# ملاحظة: هذه الاختبارات محجوزة (skip) بوضوح — لا تُحسب PASS.
# ستُفعّل وتُشغّل في Phase 2.2 بعد الدمج التدريجي.
