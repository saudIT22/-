"""Option B — rounding mode tests. Run: python3 test_rounding_modes.py"""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from decimal import Decimal
from nabbah_finance import (quantize, round_money, round_pct, metric_result, compute_sales,
                            LEGACY_COMPATIBLE as L, ACCOUNTING_HALF_UP as H, DEFAULT_ROUNDING_MODE)
P = F = 0
def ct(name, cond):
    global P, F
    if cond: P += 1; print(f"PASS: {name}")
    else: F += 1; print(f"FAIL: {name}")
q = lambda v, p, m: quantize(v, p, m)

print("[GROUP] default and metadata")
ct("default mode is LEGACY_COMPATIBLE", DEFAULT_ROUNDING_MODE == L)
ct("metric metadata carries rounding_mode", metric_result("x", Decimal("1"))["rounding_mode"] == L)
ct("engine output carries rounding_mode", compute_sales(100)["net_sales"]["rounding_mode"] == L)

print("[GROUP] exact-half values")
ct("12.25 @1dp  LEGACY=12.2 (half-even)", q(12.25, 1, L) == Decimal("12.2"))
ct("12.25 @1dp  HALF_UP=12.3", q(12.25, 1, H) == Decimal("12.3"))
ct("12.35 @1dp  LEGACY=12.3 (binary 12.3499...)", q(12.35, 1, L) == Decimal("12.3"))
ct("12.35 @1dp  HALF_UP=12.4", q(12.35, 1, H) == Decimal("12.4"))
ct("0.05 @1dp   LEGACY equals round()", q(0.05, 1, L) == Decimal(str(round(0.05, 1))))
ct("0.05 @1dp   HALF_UP=0.1", q(0.05, 1, H) == Decimal("0.1"))
ct("0.125 @2dp  LEGACY=0.12 / HALF_UP=0.13", q(0.125, 2, L) == Decimal("0.12") and q(0.125, 2, H) == Decimal("0.13"))

print("[GROUP] negative values")
ct("-12.25 LEGACY=-12.2 / HALF_UP=-12.3", q(-12.25, 1, L) == Decimal("-12.2") and q(-12.25, 1, H) == Decimal("-12.3"))
ct("-0.125 LEGACY=-0.12 / HALF_UP=-0.13", q(-0.125, 2, L) == Decimal("-0.12") and q(-0.125, 2, H) == Decimal("-0.13"))

print("[GROUP] large monetary values")
ct("123456789.125 LEGACY=.12 / HALF_UP=.13",
   q(123456789.125, 2, L) == Decimal("123456789.12") and q(123456789.125, 2, H) == Decimal("123456789.13"))
ct("9999999999.99 preserved in both modes",
   q(9999999999.99, 2, L) == Decimal("9999999999.99") and q(9999999999.99, 2, H) == Decimal("9999999999.99"))

print("[GROUP] zero, null, invalid")
ct("zero -> 0.00", q(0, 2, L) == Decimal("0.00") and q(0, 2, H) == Decimal("0.00"))
ct("None -> None (missing stays missing)", round_money(None) is None and round_pct(None, 1, H) is None)
ct("non-numeric -> None", round_money("abc") is None)
try:
    q(1, 2, "BANKERS"); ct("unknown mode rejected", False)
except ValueError:
    ct("unknown mode rejected", True)

print("[GROUP] LEGACY equals Python round() on 50,000 random floats")
random.seed(11); bad = 0
for _ in range(50000):
    v = random.choice([random.uniform(-1e7, 1e7), round(random.uniform(-1000, 1000), 3), random.randint(-10**9, 10**9) / 8])
    pl = random.choice([0, 1, 2, 3])
    if q(v, pl, L) != Decimal(str(round(v, pl))): bad += 1
ct(f"0 mismatches vs round() (found {bad})", bad == 0)

print(f"\nTOTAL: {P+F} | PASSED: {P} | FAILED: {F}")
sys.exit(0 if F == 0 else 1)
