"""
Real API integration tests — GET /company/intelligence, POST /company/intelligence/ask
Uses: production FastAPI app, production SQLModel models, persisted fixtures (add+commit),
real JWT via main.create_token -> main.get_current_user. No auth mocking.
Only the external AI call (company_gemini) is replaced, to avoid a live Gemini request.

Requires: pytest, fastapi, sqlmodel, bcrypt, PyJWT, httpx. Repo layout: tests/ next to main.py and phase22/.
Run: python -m pytest tests/test_api_intelligence.py -v
"""
import json
import pytest
from datetime import datetime
from sqlmodel import Session


def _mk_company(m, s, name, *, active=1, sales=(100000, 80000), expenses=(60000, 50000)):
    owner = m.User(name=f"{name}-owner", email=f"{name}@t.com", password_hash=m.hash_password("Pass12345"))
    s.add(owner); s.commit(); s.refresh(owner)
    comp = m.Company(name=name, owner_id=owner.id, is_active=active)
    s.add(comp); s.commit(); s.refresh(comp)
    owner.company_id = comp.id; s.add(owner); s.commit(); s.refresh(owner)
    br = m.CompanyBranch(company_id=comp.id, name=f"{name}-B1", is_active=1)
    s.add(br); s.commit(); s.refresh(br)
    for per, sa, ex in (("2026-09", sales[0], expenses[0]), ("2026-08", sales[1], expenses[1])):
        s.add(m.CompanyEntry(company_id=comp.id, branch_id=br.id, branch_name=br.name, period=per,
                             sales=sa, invoices=1000, expenses=ex))
    s.commit()
    return owner, comp, br


def _member(m, s, comp, role, email):
    u = m.User(name=role, email=email, password_hash=m.hash_password("Pass12345"), company_id=comp.id)
    s.add(u); s.commit(); s.refresh(u)
    s.add(m.CompanyMember(company_id=comp.id, name=role, email=email, role=role)); s.commit()
    return u


def _auth(m, user):
    return {"Authorization": f"Bearer {m.create_token(user.id)}"}


@pytest.fixture
def world(app_module, clean_db):
    m = app_module
    with Session(m.engine) as s:
        a_owner, a, a_br = _mk_company(m, s, "CompanyA")
        b_owner, b, b_br = _mk_company(m, s, "CompanyB", sales=(9999999, 8888888), expenses=(1, 1))
        staff = _member(m, s, a, "staff", "staff@a.com")
        mgr = _member(m, s, a, "manager", "mgr@a.com")
        acc = _member(m, s, a, "accountant", "acc@a.com")
        ids = dict(a=a.id, b=b.id)
        users = {k: v for k, v in dict(a_owner=a_owner, b_owner=b_owner, staff=staff, mgr=mgr, acc=acc).items()}
        for u in users.values():
            s.refresh(u)
    return m, users, ids


# ── Authentication ───────────────────────────────────────────
def test_get_requires_auth(client):
    assert client.get("/company/intelligence").status_code == 401

def test_post_requires_auth(client):
    assert client.post("/company/intelligence/ask", json={"question": "x"}).status_code == 401

def test_invalid_token_rejected(client):
    r = client.get("/company/intelligence", headers={"Authorization": "Bearer bad.token.x"})
    assert r.status_code == 401


# ── Contract + period awareness ──────────────────────────────
def test_owner_gets_contract(client, world):
    m, u, _ = world
    r = client.get("/company/intelligence", headers=_auth(m, u["a_owner"]))
    assert r.status_code == 200
    d = r.json()
    assert d["period"] == "2026-09"
    assert d["comparison_period"] == "2026-08"
    assert d["has_comparison"] is True
    ns = d["kpis"]["net_sales"]
    for key in ("metric_id", "value", "currency", "period", "source",
                "calculation_version", "data_quality", "timestamp"):
        assert key in ns, key
    assert ns["value"] == 100000
    assert d["kpis"]["growth"]["value_decimal"] == "25.00"

def test_explicit_period_without_comparison(client, world):
    m, u, _ = world
    r = client.get("/company/intelligence?period=2026-08", headers=_auth(m, u["a_owner"]))
    assert r.status_code == 200
    d = r.json()
    assert d["period"] == "2026-08" and d["has_comparison"] is False
    assert d["kpis"]["growth"]["value"] is None
    assert any(g["missing"] == "comparison_period_data" for g in d["data_gaps"])


# ── Tenant isolation ─────────────────────────────────────────
def test_company_a_never_sees_company_b(client, world):
    m, u, _ = world
    body = client.get("/company/intelligence", headers=_auth(m, u["a_owner"])).text
    assert "9999999" not in body and "CompanyB" not in body

def test_company_b_never_sees_company_a(client, world):
    m, u, _ = world
    d = client.get("/company/intelligence", headers=_auth(m, u["b_owner"])).json()
    assert d["kpis"]["net_sales"]["value"] == 9999999
    assert "CompanyA" not in json.dumps(d, ensure_ascii=False)

def test_company_id_query_param_cannot_escalate(client, world):
    m, u, ids = world
    r = client.get(f"/company/intelligence?company_id={ids['b']}", headers=_auth(m, u["a_owner"]))
    assert r.status_code == 200 and r.json()["kpis"]["net_sales"]["value"] == 100000

def test_company_id_body_cannot_escalate(client, world, monkeypatch):
    m, u, ids = world
    seen = {}
    def fake_gemini(prompt, company=None, lang="ar"):
        seen["prompt"] = prompt
        return "FACTS: ok"
    monkeypatch.setattr(m, "company_gemini", fake_gemini)
    r = client.post("/company/intelligence/ask", headers=_auth(m, u["a_owner"]),
                    json={"question": "x", "company_id": ids["b"]})
    assert r.status_code == 200
    assert "9999999" not in r.text
    if "prompt" in seen:
        assert "9999999" not in seen["prompt"]


# ── RBAC ─────────────────────────────────────────────────────
def test_staff_forbidden(client, world):
    m, u, _ = world
    assert client.get("/company/intelligence", headers=_auth(m, u["staff"])).status_code == 403

def test_manager_forbidden(client, world):
    m, u, _ = world
    assert client.get("/company/intelligence", headers=_auth(m, u["mgr"])).status_code == 403

def test_accountant_allowed(client, world):
    m, u, _ = world
    assert client.get("/company/intelligence", headers=_auth(m, u["acc"])).status_code == 200

def test_staff_forbidden_on_ask(client, world):
    m, u, _ = world
    r = client.post("/company/intelligence/ask", headers=_auth(m, u["staff"]), json={"question": "x"})
    assert r.status_code == 403


# ── Inactive company / missing modules ───────────────────────
def test_inactive_company_402(client, app_module, clean_db):
    m = app_module
    with Session(m.engine) as s:
        owner, _, _ = _mk_company(m, s, "Inactive", active=0)
        s.refresh(owner)
    assert client.get("/company/intelligence", headers=_auth(m, owner)).status_code == 402

def test_missing_phase22_returns_503(client, world, monkeypatch):
    m, u, _ = world
    monkeypatch.setattr(m, "_load_phase22_bridge", lambda: None)
    r = client.get("/company/intelligence", headers=_auth(m, u["a_owner"]))
    assert r.status_code == 503 and "Traceback" not in r.text


# ── Existing endpoints still work ────────────────────────────
def test_me_still_works(client, world):
    m, u, _ = world
    assert client.get("/me", headers=_auth(m, u["a_owner"])).status_code == 200

def test_financial_overview_still_works(client, world):
    m, u, _ = world
    assert client.get("/company/financial-overview", headers=_auth(m, u["a_owner"])).status_code == 200


# ── Period handling through the real endpoint ────────────────
def test_same_period_latest_submission_wins(client, world):
    m, u, ids = world
    with Session(m.engine) as s:
        br = s.exec(m.select(m.CompanyBranch).where(m.CompanyBranch.company_id == ids["a"])).first()
        s.add(m.CompanyEntry(company_id=ids["a"], branch_id=br.id, branch_name=br.name, period="2026-09",
                             sales=150000, invoices=1000, expenses=60000, created_at=datetime(2030, 1, 1)))
        s.commit()
    d = client.get("/company/intelligence", headers=_auth(m, u["a_owner"])).json()
    assert d["kpis"]["net_sales"]["value"] == 150000  # correction replaces, not added


def test_invalid_period_excluded_and_reported(client, world):
    m, u, ids = world
    with Session(m.engine) as s:
        br = s.exec(m.select(m.CompanyBranch).where(m.CompanyBranch.company_id == ids["a"])).first()
        s.add(m.CompanyEntry(company_id=ids["a"], branch_id=br.id, branch_name=br.name, period="not-a-date",
                             sales=7777777, invoices=1, expenses=0))
        s.commit()
    r = client.get("/company/intelligence", headers=_auth(m, u["a_owner"]))
    assert r.status_code == 200 and "7777777" not in r.text
    assert any(g["missing"] == "valid_period" for g in r.json()["data_gaps"])


# ── Branch isolation ─────────────────────────────────────────
def test_inactive_branch_excluded(client, world):
    m, u, ids = world
    with Session(m.engine) as s:
        dead = m.CompanyBranch(company_id=ids["a"], name="Closed", is_active=0)
        s.add(dead); s.commit(); s.refresh(dead)
        s.add(m.CompanyEntry(company_id=ids["a"], branch_id=dead.id, branch_name="Closed", period="2026-09",
                             sales=5555555, invoices=1, expenses=0))
        s.commit()
    assert "5555555" not in client.get("/company/intelligence", headers=_auth(m, u["a_owner"])).text


def test_row_pointing_to_other_company_branch_excluded(client, world):
    m, u, ids = world
    with Session(m.engine) as s:
        b_branch = s.exec(m.select(m.CompanyBranch).where(m.CompanyBranch.company_id == ids["b"])).first()
        s.add(m.CompanyEntry(company_id=ids["a"], branch_id=b_branch.id, branch_name="x", period="2026-09",
                             sales=4444444, invoices=1, expenses=0))
        s.commit()
    assert "4444444" not in client.get("/company/intelligence", headers=_auth(m, u["a_owner"])).text


# ── AI respects data quality ─────────────────────────────────
def test_ai_blocked_when_company_has_no_data(client, app_module, clean_db, monkeypatch):
    m = app_module
    with Session(m.engine) as s:
        owner = m.User(name="Empty", email="empty@t.com", password_hash=m.hash_password("Pass12345"))
        s.add(owner); s.commit(); s.refresh(owner)
        comp = m.Company(name="EmptyCo", owner_id=owner.id, is_active=1)
        s.add(comp); s.commit(); s.refresh(comp)
        owner.company_id = comp.id; s.add(owner); s.commit(); s.refresh(owner)

    def must_not_call(*a, **k):
        raise AssertionError("AI must not be called when the quality gate blocks")
    monkeypatch.setattr(m, "company_gemini", must_not_call)
    r = client.post("/company/intelligence/ask", headers=_auth(m, owner), json={"question": "why?"})
    assert r.status_code == 200
    d = r.json()
    assert d["gate"]["status"] == "BLOCK" and d["ai_called"] is False
    assert d["response"]["RECOMMENDATIONS"] == []
