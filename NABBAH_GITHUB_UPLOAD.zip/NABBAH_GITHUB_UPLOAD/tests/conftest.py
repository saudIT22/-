"""
NABBAH test configuration.
- Forces an isolated SQLite test database BEFORE the app is imported.
- Refuses to run against any Railway / non-SQLite database.
- Finds main.py whether tests/ sits at the repo root or one level deeper.
"""
import os
import sys

os.environ["TESTING"] = "true"
os.environ["ENVIRONMENT"] = "development"
os.environ["DATABASE_URL"] = "sqlite:///./test_nabbah.db"
os.environ.setdefault("SECRET_KEY", "test-only-secret-not-for-production")
os.environ.setdefault("ADMIN_KEY", "test-admin-key")
os.environ.setdefault("GEMINI_API_KEY", "test-only-dummy-key")

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
for _cand in (os.path.dirname(_HERE), os.path.dirname(os.path.dirname(_HERE))):
    if os.path.exists(os.path.join(_cand, "main.py")):
        sys.path.insert(0, _cand)
        break


def _guard_production_db():
    db = os.environ.get("DATABASE_URL", "").lower()
    if any(x in db for x in ("railway", "rlwy")) or not db.startswith("sqlite"):
        pytest.exit("SAFETY STOP: tests must use an isolated SQLite database.", returncode=1)


_guard_production_db()


@pytest.fixture(scope="session")
def app_module():
    _guard_production_db()
    import main
    return main


@pytest.fixture(scope="session")
def client(app_module):
    from fastapi.testclient import TestClient
    from sqlmodel import SQLModel
    SQLModel.metadata.create_all(app_module.engine)
    return TestClient(app_module.app)


@pytest.fixture
def clean_db(app_module):
    from sqlmodel import SQLModel
    SQLModel.metadata.drop_all(app_module.engine)
    SQLModel.metadata.create_all(app_module.engine)
    yield


def pytest_sessionfinish(session, exitstatus):
    try:
        os.remove("./test_nabbah.db")
    except OSError:
        pass
