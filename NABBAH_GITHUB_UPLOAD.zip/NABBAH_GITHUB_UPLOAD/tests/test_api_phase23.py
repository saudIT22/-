"""Phase 2.3 API tests — real app, real DB models, real JWT (run in CI)."""
import pytest
from sqlmodel import Session, select
from test_api_intelligence import _mk_company, _member, _auth


@pytest.fixture
def w(app_module, clean_db):
    m = app_module
    with Session(m.engine) as s:
        a_owner, a, _ = _mk_company(m, s, "CoA")
        b_owner, b, _ = _mk_company(m, s, "CoB", sales=(9999999, 8888888), expenses=(1, 1))
        acc = _member(m, s, a, "accountant", "acc@coa.com")
        staff = _member(m, s, a, "staff", "st@coa.com")
        for u in (a_owner, b_owner, acc, staff):
            s.refresh(u)
    return m, dict(a=a_owner, b=b_owner, acc=acc, staff=staff)


def _first_signal(client, m, user):
    d = client.get("/company/executive-intelligence", headers=_auth(m, user)).json()
    return d, (d["risks"] + d["opportunities"])[0]["id"]


def test_exec_requires_auth(client):
    assert client.get("/company/executive-intelligence").status_code == 401

def test_exec_owner_sections(client, w):
    m, u = w
    r = client.get("/company/executive-intelligence", headers=_auth(m, u["a"]))
    assert r.status_code == 200
    d = r.json()
    for k in ("summary", "revenue_vs_target", "profit_vs_target", "branch_performance", "risks",
              "opportunities", "recommendations", "data_quality", "forecast"):
        assert k in d
    assert d["summary"]["net_sales"]["value"] == 100000 and d["period"] == "2026-09"

def test_exec_staff_forbidden(client, w):
    m, u = w
    assert client.get("/company/executive-intelligence", headers=_auth(m, u["staff"])).status_code == 403

def test_exec_tenant_isolation(client, w):
    m, u = w
    assert "9999999" not in client.get("/company/executive-intelligence", headers=_auth(m, u["a"])).text

def test_exec_missing_engine_503(client, w, monkeypatch):
    m, u = w
    monkeypatch.setattr(m, "_load_phase23", lambda: (None, None))
    assert client.get("/company/executive-intelligence", headers=_auth(m, u["a"])).status_code == 503

def test_recommendation_to_decision_flow(client, w):
    m, u = w
    _, sid = _first_signal(client, m, u["a"])
    r = client.post("/company/recommendations/to-decision", headers=_auth(m, u["a"]),
                    json={"signal_id": sid, "owner": "Ali", "due_date": "2099-01-01", "expected_impact_value": 999999})
    assert r.status_code == 200
    body = r.json()
    with Session(m.engine) as s:
        d = s.get(m.CompanyDecision, body["decision_id"])
        assert d.source_signal == sid and d.status == "open" and d.impact_status == "expected"
        assert d.expected_impact_value != 999999          # client numbers ignored
        assert len(body["action_ids"]) >= 1
        logs = s.exec(select(m.AuditLog).where(m.AuditLog.action == "decision_from_recommendation")).all()
        assert logs

def test_to_decision_accountant_forbidden(client, w):
    m, u = w
    _, sid = _first_signal(client, m, u["acc"])
    r = client.post("/company/recommendations/to-decision", headers=_auth(m, u["acc"]), json={"signal_id": sid})
    assert r.status_code == 403

def test_to_decision_unknown_signal_404(client, w):
    m, u = w
    r = client.post("/company/recommendations/to-decision", headers=_auth(m, u["a"]), json={"signal_id": "nope"})
    assert r.status_code == 404

def test_actions_lifecycle_and_isolation(client, w):
    m, u = w
    _, sid = _first_signal(client, m, u["a"])
    aid = client.post("/company/recommendations/to-decision", headers=_auth(m, u["a"]),
                      json={"signal_id": sid}).json()["action_ids"][0]
    assert client.get("/company/actions", headers=_auth(m, u["a"])).json()["count"] >= 1
    assert client.get("/company/actions", headers=_auth(m, u["b"])).json()["count"] == 0
    assert client.post("/company/actions/update", headers=_auth(m, u["b"]), json={"id": aid, "status": "completed"}).status_code == 404
    assert client.post("/company/actions/update", headers=_auth(m, u["a"]), json={"id": aid, "status": "done?"}).status_code == 400
    r = client.post("/company/actions/update", headers=_auth(m, u["a"]), json={"id": aid, "status": "completed", "progress": 10})
    assert r.status_code == 200 and r.json()["action"]["progress"] == 100
    assert client.post("/company/actions/update", headers=_auth(m, u["a"]), json={"id": aid, "status": "in_progress"}).status_code == 409

def test_measure_same_month_is_insufficient(client, w):
    m, u = w
    _, sid = _first_signal(client, m, u["a"])
    did = client.post("/company/recommendations/to-decision", headers=_auth(m, u["a"]), json={"signal_id": sid}).json()["decision_id"]
    r = client.post("/company/decisions/measure", headers=_auth(m, u["a"]), json={"decision_id": did})
    assert r.status_code == 200 and r.json()["impact_status"] == "insufficient_data"

def test_existing_decisions_page_still_works(client, w):
    m, u = w
    assert client.get("/company/decisions", headers=_auth(m, u["a"])).status_code == 200
