"""
NABBAH — اختبارات RBAC على الـEndpoints الفعلية (Phase 1.3 — معالجة الفجوات)
تعالج ملاحظات المراجعة:
  الفجوة ٢: تثبت أن الـendpoints الفعلية محمية (لا المصفوفة فقط).
  الفجوة ٣: تثبت أن الحقول الحساسة تُحذف من مخرجات الـendpoint الفعلية.

تبني مستخدمين بأدوار مختلفة وتضربهم على endpoints حقيقية.
"""
import pytest
from sqlmodel import Session


def _make_company_with_roles(m):
    """ينشئ شركة + مالك + محاسب + مدير فرع + موظف. يرجع القاموس."""
    with Session(m.engine) as s:
        # المالك
        owner = m.User(name="Owner", email="own@t.com", password_hash=m.hash_password("Pass12345"))
        s.add(owner); s.commit(); s.refresh(owner)
        comp = m.Company(name="TestCo", owner_id=owner.id, is_active=1)
        s.add(comp); s.commit(); s.refresh(comp)
        owner.company_id = comp.id; s.add(owner); s.commit(); s.refresh(owner)

        # فرع + بيانات HR فيها رواتب
        br = m.CompanyBranch(company_id=comp.id, name="Main Branch", is_active=1)
        s.add(br); s.commit(); s.refresh(br)
        entry = m.CompanyEntry(branch_id=br.id, sales=1000000, expenses=700000,
                               profit=300000, margin=30, customers=5000, period="1/2026")
        s.add(entry); s.commit()
        # بيانات HR موسّعة فيها رواتب (حسّاسة)
        import json
        hr_data = json.dumps({"عدد الموظفين": 50, "إجمالي الرواتب": 280000}, ensure_ascii=False)
        s.add(m.CompanyModuleEntry(company_id=comp.id, module="hr", period="1/2026", data=hr_data))
        s.commit()

        # أعضاء بأدوار مختلفة
        accountant = m.User(name="Acc", email="acc@t.com", password_hash=m.hash_password("Pass12345"), company_id=comp.id)
        manager = m.User(name="Mgr", email="mgr@t.com", password_hash=m.hash_password("Pass12345"), company_id=comp.id)
        staff = m.User(name="Stf", email="stf@t.com", password_hash=m.hash_password("Pass12345"), company_id=comp.id)
        s.add_all([accountant, manager, staff]); s.commit()
        s.add(m.CompanyMember(company_id=comp.id, name="Acc", email="acc@t.com", role="accountant"))
        s.add(m.CompanyMember(company_id=comp.id, name="Mgr", email="mgr@t.com", role="manager", branch_id=br.id))
        s.add(m.CompanyMember(company_id=comp.id, name="Stf", email="stf@t.com", role="staff"))
        s.commit()
        return {"comp_id": comp.id, "owner_email": "own@t.com",
                "acc_email": "acc@t.com", "mgr_email": "mgr@t.com", "stf_email": "stf@t.com"}


def _token(client, email):
    r = client.post("/login", json={"email": email, "password": "Pass12345"})
    return r.json().get("token") if r.status_code == 200 else None


# ═══════════ الفجوة ٢: حماية الـendpoints الفعلية ═══════════
def test_endpoint_finance_rejects_manager(client, app_module, clean_db):
    """
    endpoint المالية الفعلي يرفض مدير الفرع (403).
    يثبت الحماية على مستوى المسار، لا المصفوفة فقط.
    """
    info = _make_company_with_roles(app_module)
    tok = _token(client, info["mgr_email"])
    if not tok:
        pytest.skip("تعذّر تسجيل الدخول")
    r = client.get("/company/financial-overview", headers={"Authorization": f"Bearer {tok}"})
    assert r.status_code == 403  # مدير الفرع محروم من المالية


def test_endpoint_finance_rejects_staff(client, app_module, clean_db):
    """endpoint المالية يرفض الموظف."""
    info = _make_company_with_roles(app_module)
    tok = _token(client, info["stf_email"])
    if not tok:
        pytest.skip("تعذّر تسجيل الدخول")
    r = client.get("/company/cashflow", headers={"Authorization": f"Bearer {tok}"})
    assert r.status_code == 403


def test_endpoint_finance_allows_accountant(client, app_module, clean_db):
    """endpoint المالية يسمح للمحاسب."""
    info = _make_company_with_roles(app_module)
    tok = _token(client, info["acc_email"])
    if not tok:
        pytest.skip("تعذّر تسجيل الدخول")
    r = client.get("/company/financial-overview", headers={"Authorization": f"Bearer {tok}"})
    assert r.status_code in (200, 402)  # مسموح (أو قيد التفعيل)


def test_endpoint_admin_rejects_non_owner(client, app_module, clean_db):
    """endpoints الإدارة (team) ترفض غير المالك."""
    info = _make_company_with_roles(app_module)
    tok = _token(client, info["acc_email"])
    if not tok:
        pytest.skip("تعذّر تسجيل الدخول")
    r = client.get("/company/team", headers={"Authorization": f"Bearer {tok}"})
    assert r.status_code == 403  # للمالك فقط


# ═══════════ الفجوة ٣: الحقول الحساسة محذوفة من المخرجات الفعلية ═══════════
def test_hr_salary_hidden_from_manager(client, app_module, clean_db):
    """
    الأهم: مخرجات endpoint HR الفعلية لا تكشف الرواتب لمدير الفرع.
    يثبت أن التصفية تعمل على الاستجابة الحقيقية، لا القاموس المعزول.
    """
    info = _make_company_with_roles(app_module)
    tok = _token(client, info["mgr_email"])
    if not tok:
        pytest.skip("تعذّر تسجيل الدخول")
    r = client.get("/company/hr-analytics", headers={"Authorization": f"Bearer {tok}"})
    if r.status_code == 200:
        data = r.json()
        # نبحث عن مؤشر الرواتب في المخرجات
        for metric in data.get("metrics", []):
            if metric.get("key") == "salary_ratio":
                # يجب أن يكون مخفياً (value=None أو restricted)
                assert metric.get("value") is None or metric.get("restricted") is True


def test_hr_salary_visible_to_owner(client, app_module, clean_db):
    """المالك يرى نسبة الرواتب في HR."""
    info = _make_company_with_roles(app_module)
    tok = _token(client, info["owner_email"])
    if not tok:
        pytest.skip("تعذّر تسجيل الدخول")
    r = client.get("/company/hr-analytics", headers={"Authorization": f"Bearer {tok}"})
    if r.status_code == 200:
        data = r.json()
        for metric in data.get("metrics", []):
            if metric.get("key") == "salary_ratio" and metric.get("has_data"):
                # المالك يرى القيمة الفعلية
                assert metric.get("restricted") is not True
