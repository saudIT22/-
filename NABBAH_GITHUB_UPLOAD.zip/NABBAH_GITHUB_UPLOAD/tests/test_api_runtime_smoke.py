"""Runtime smoke + RBAC matrix + IDOR matrix + scenario/action/memory runtime cases.
Real FastAPI app, real SQLModel tables, real JWT. Runs in CI (python -m pytest tests -v)."""
import json
from datetime import datetime
import pytest
from sqlmodel import Session, select
from test_api_intelligence import _mk_company, _member, _auth


@pytest.fixture
def env(app_module, clean_db):
    m = app_module
    with Session(m.engine) as s:
        a, ca, bra = _mk_company(m, s, "SmokeA")
        b, cb, brb = _mk_company(m, s, "SmokeB", sales=(700000, 600000), expenses=(1, 1))
        br2 = m.CompanyBranch(company_id=ca.id, name="SmokeA-B2", is_active=1); s.add(br2); s.commit(); s.refresh(br2)
        for per, sa in (("2026-09", 50000), ("2026-08", 40000)):
            s.add(m.CompanyEntry(company_id=ca.id, branch_id=br2.id, branch_name=br2.name, period=per, sales=sa, invoices=100, expenses=30000))
        s.add(m.CompanyModuleEntry(company_id=ca.id, module="finance", period="2026-09",
                                   data=json.dumps({"تكلفة البضاعة المباعة": 40000, "الرواتب": 20000, "الإيجار": 10000, "التسويق": 5000}, ensure_ascii=False)))
        s.commit()
        roles = {r: _member(m, s, ca, r, f"{r}@smoke.com") for r in ("accountant", "manager", "staff")}
        for u in [a, b, *roles.values()]: s.refresh(u)
        ids = dict(ca=ca.id, cb=cb.id, bra=bra.id, br2=br2.id, brb=brb.id)
    return m, {"owner": a, "b": b, **roles}, ids


def H(m, u): return _auth(m, u)
SC = {"name": "خطة النمو", "scenario_type": "growth", "assumptions": {"revenue_growth_pct": 10}}


def _decision(client, m, owner):
    d = client.get("/company/executive-intelligence", headers=H(m, owner)).json()
    sid = (d["risks"] + d["opportunities"])[0]["id"]
    return client.post("/company/recommendations/to-decision", headers=H(m, owner), json={"signal_id": sid}).json()


# ── RBAC matrix (roles that exist: owner, accountant, manager, staff) ──
@pytest.mark.parametrize("role,view,create,archive", [
    ("owner", 200, 200, 200), ("accountant", 200, 200, 403), ("manager", 403, 403, 403), ("staff", 403, 403, 403)])
def test_rbac_scenarios(client, env, role, view, create, archive):
    m, u, _ = env
    sid = client.post("/company/scenarios", headers=H(m, u["owner"]), json=SC).json()["id"]
    assert client.get("/company/scenarios", headers=H(m, u[role])).status_code == view
    assert client.post("/company/scenarios", headers=H(m, u[role]), json=SC).status_code == create
    assert client.put(f"/company/scenarios/{sid}", headers=H(m, u[role]), json=SC).status_code == create
    assert client.delete(f"/company/scenarios/{sid}", headers=H(m, u[role])).status_code == archive

@pytest.mark.parametrize("role,view,edit", [("owner", 200, 200), ("accountant", 403, 403), ("manager", 200, 403), ("staff", 403, 403)])
def test_rbac_actions_and_memory(client, env, role, view, edit):
    m, u, _ = env
    dec = _decision(client, m, u["owner"]); aid = dec["action_ids"][0]
    assert client.get("/company/actions", headers=H(m, u[role])).status_code == view
    assert client.get(f"/company/decisions/{dec['decision_id']}/memory", headers=H(m, u[role])).status_code == view
    assert client.post("/company/actions/update", headers=H(m, u[role]), json={"id": aid, "progress": 50}).status_code == edit
    assert client.post("/company/actions", headers=H(m, u[role]), json={"decision_id": dec["decision_id"], "title": "x"}).status_code == edit
    assert client.post("/company/decisions/measure", headers=H(m, u[role]), json={"decision_id": dec["decision_id"]}).status_code in ((200,) if edit == 200 else (403,))

# ── IDOR matrix: Company B uses Company A's real IDs ──
def test_idor_matrix(client, env):
    m, u, ids = env
    sid = client.post("/company/scenarios", headers=H(m, u["owner"]), json=SC).json()["id"]
    dec = _decision(client, m, u["owner"]); did, aid = dec["decision_id"], dec["action_ids"][0]
    B = H(m, u["b"])
    for method, url, body in [("GET", f"/company/scenarios/{sid}", None), ("PUT", f"/company/scenarios/{sid}", SC),
                              ("POST", f"/company/scenarios/{sid}/run", None), ("GET", f"/company/scenarios/{sid}/compare", None),
                              ("DELETE", f"/company/scenarios/{sid}", None), ("POST", "/company/actions/update", {"id": aid, "progress": 10}),
                              ("GET", f"/company/actions/{aid}/history", None), ("GET", f"/company/decisions/{did}/memory", None),
                              ("POST", "/company/decisions/measure", {"decision_id": did}),
                              ("POST", "/company/actions", {"decision_id": did, "title": "x"})]:
        r = client.request(method, url, headers=B, json=body)
        assert r.status_code in (403, 404), (method, url, r.status_code)
        assert "SmokeA" not in r.text
    assert client.post("/company/scenarios", headers=B, json={**SC, "branch_id": ids["bra"]}).status_code == 404
    assert "SmokeA" not in client.get("/company/actions", headers=B).text
    assert "SmokeA" not in client.get("/company/decision-memory?metric_id=growth", headers=B).text

# ── Scenario runtime ──
@pytest.mark.parametrize("assumptions,expect_rev,expect_cost", [
    ({"revenue_growth_pct": 10}, 165000, None), ({"revenue_growth_pct": -10}, 135000, None),
    ({"expense_change_pct": 10}, 150000, None), ({"expense_change_pct": -10}, 150000, None),
    ({"cogs_change_pct": -5}, 150000, None), ({"payroll_change_pct": 10}, 150000, None),
    ({"marketing_change_pct": -50}, 150000, None), ({"revenue_growth_pct": -90}, 15000, None),
    ({"revenue_growth_pct": 300}, 600000, None)])
def test_scenario_cases(client, env, assumptions, expect_rev, expect_cost):
    m, u, _ = env
    r = client.post("/company/scenarios", headers=H(m, u["owner"]), json={**SC, "assumptions": assumptions})
    assert r.status_code == 200
    rev = [x for x in r.json()["results"]["comparison"] if x["metric"] == "revenue"][0]
    assert rev["baseline"]["value"] == 150000 and rev["scenario"]["value"] == expect_rev

def test_scenario_breakdown_applied_and_baseline_untouched(client, env):
    m, u, _ = env
    with Session(m.engine) as s:
        before = [(e.id, e.sales, e.expenses, e.profit) for e in s.exec(select(m.CompanyEntry)).all()]
    r = client.post("/company/scenarios", headers=H(m, u["owner"]),
                    json={**SC, "assumptions": {"cogs_change_pct": -10}, "results": {"profit_impact": {"value": 999999}}}).json()
    assert r["results"]["baseline_values"]["has_breakdown"] is True and "cogs_change_pct" in r["results"]["applied"]
    assert r["results"]["profit_impact"]["value"] == 4000            # 10% of COGS 40000 — server math, client value ignored
    with Session(m.engine) as s:
        assert before == [(e.id, e.sales, e.expenses, e.profit) for e in s.exec(select(m.CompanyEntry)).all()]

def test_scenario_branch_specific_and_invalid(client, env):
    m, u, ids = env
    r = client.post("/company/scenarios", headers=H(m, u["owner"]), json={**SC, "branch_id": ids["br2"]}).json()
    assert [x for x in r["results"]["comparison"] if x["metric"] == "revenue"][0]["baseline"]["value"] == 50000
    for bad in ({"revenue_growth_pct": 301}, {"revenue_growth_pct": -91}, {"revenue_growth_pct": "abc"}, {}):
        assert client.post("/company/scenarios", headers=H(m, u["owner"]), json={**SC, "assumptions": bad}).status_code == 422
    r = client.post("/company/scenarios", headers=H(m, u["owner"]), json={**SC, "base_period": "2020-01"}).json()
    assert r["results"]["status"] == "insufficient_data" and r["status"] == "draft"

# ── Action Center runtime ──
def test_action_progress_and_lifecycle(client, env):
    m, u, _ = env
    aid = _decision(client, m, u["owner"])["action_ids"][0]
    up = lambda b: client.post("/company/actions/update", headers=H(m, u["owner"]), json={"id": aid, **b})
    for p in (0, 50):
        assert up({"progress": p}).json()["action"]["progress"] == p
    assert up({"progress": -1}).status_code == 400 and up({"progress": 101}).status_code == 400
    assert up({"status": "in_progress", "progress": 100}).json()["action"]["progress"] == 100
    assert up({"status": "completed", "progress": 30}).json()["action"]["progress"] == 100
    assert up({"note": "x"}).status_code == 409
    lst = client.get("/company/actions?sort=priority", headers=H(m, u["owner"])).json()
    assert lst["summary"]["completed"] >= 1 and client.get("/company/actions?status=completed", headers=H(m, u["owner"])).json()["count"] >= 1

# ── Decision memory runtime ──
def test_memory_statuses_and_wording(client, env):
    m, u, ids = env
    did = _decision(client, m, u["owner"])["decision_id"]
    assert client.post("/company/decisions/measure", headers=H(m, u["owner"]), json={"decision_id": did}).json()["outcome_status"] == "pending_measurement"
    with Session(m.engine) as s:
        d = s.get(m.CompanyDecision, did); d.created_at = datetime(2026, 8, 3); d.metric_id = "net_sales"; d.baseline_value = 100.0; d.branch_id = None
        s.add(d); s.commit()
    r = client.post("/company/decisions/measure", headers=H(m, u["owner"]), json={"decision_id": did}).json()
    assert r["outcome_status"] == "verified"
    text = json.dumps(r, ensure_ascii=False)
    assert "تسبب" not in text.replace("لا تثبت أن القرار هو السبب", "") and "caused" not in text.replace("do not prove the decision caused it", "")
    with Session(m.engine) as s:
        s.add(m.CompanyEntry(company_id=ids["ca"], branch_id=ids["bra"], branch_name="x", period="2026-10", sales=1, invoices=1, expenses=0)); s.commit()
    assert client.post("/company/decisions/measure", headers=H(m, u["owner"]), json={"decision_id": did}).json()["outcome_status"] == "measured"
    with Session(m.engine) as s:
        d = s.get(m.CompanyDecision, did); d.status = "cancelled"; s.add(d); s.commit()
    assert client.post("/company/decisions/measure", headers=H(m, u["owner"]), json={"decision_id": did}).json()["outcome_status"] == "cancelled"
