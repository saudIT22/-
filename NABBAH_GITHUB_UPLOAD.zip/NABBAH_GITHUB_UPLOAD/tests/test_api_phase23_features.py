"""API tests — saved scenarios, Action Center, decision memory (run in CI)."""
from datetime import datetime
import pytest
from sqlmodel import Session, select
from test_api_intelligence import _mk_company, _member, _auth


@pytest.fixture
def w(app_module, clean_db):
    m = app_module
    with Session(m.engine) as s:
        a, ca, br = _mk_company(m, s, "CoA")
        b, cb, _ = _mk_company(m, s, "CoB", sales=(9999999, 8888888), expenses=(1, 1))
        acc = _member(m, s, ca, "accountant", "acc@a.com"); staff = _member(m, s, ca, "staff", "st@a.com")
        for u in (a, b, acc, staff): s.refresh(u)
        ids = {"ca": ca.id, "cb": cb.id, "br": br.id}
    return m, dict(a=a, b=b, acc=acc, staff=staff), ids

SC = {"name": "خطة النمو", "scenario_type": "growth", "assumptions": {"revenue_growth_pct": 10}}

# ── Scenarios ──
def test_scenario_create_list_get_compare(client, w):
    m, u, _ = w
    r = client.post("/company/scenarios", headers=_auth(m, u["a"]), json=SC)
    assert r.status_code == 200
    sc = r.json(); assert sc["status"] == "ran" and sc["is_estimate"]
    rev = [x for x in sc["results"]["comparison"] if x["metric"] == "revenue"][0]
    assert rev["baseline"]["value"] == 100000 and rev["scenario"]["value"] == 110000
    assert client.get("/company/scenarios", headers=_auth(m, u["a"])).json()["count"] == 1
    assert client.get(f"/company/scenarios/{sc['id']}", headers=_auth(m, u["a"])).status_code == 200
    assert client.get(f"/company/scenarios/{sc['id']}/compare", headers=_auth(m, u["a"])).json()["comparison"]

def test_scenario_validation_422(client, w):
    m, u, _ = w
    r = client.post("/company/scenarios", headers=_auth(m, u["a"]), json={"name": "x", "assumptions": {"revenue_growth_pct": 999}})
    assert r.status_code == 422 and r.json()["detail"]["field"] == "revenue_growth_pct"

def test_scenario_update_and_run(client, w):
    m, u, _ = w
    sid = client.post("/company/scenarios", headers=_auth(m, u["a"]), json=SC).json()["id"]
    r = client.put(f"/company/scenarios/{sid}", headers=_auth(m, u["a"]), json={**SC, "assumptions": {"expense_change_pct": -10}})
    assert r.status_code == 200 and r.json()["assumptions"] == {"expense_change_pct": "-10"}
    assert client.post(f"/company/scenarios/{sid}/run", headers=_auth(m, u["a"])).status_code == 200

def test_scenario_roles(client, w):
    m, u, _ = w
    assert client.post("/company/scenarios", headers=_auth(m, u["acc"]), json=SC).status_code == 200   # finance edit
    assert client.get("/company/scenarios", headers=_auth(m, u["staff"])).status_code == 403
    sid = client.get("/company/scenarios", headers=_auth(m, u["a"])).json()["scenarios"][0]["id"]
    assert client.delete(f"/company/scenarios/{sid}", headers=_auth(m, u["acc"])).status_code == 403      # owner only
    assert client.delete(f"/company/scenarios/{sid}", headers=_auth(m, u["a"])).status_code == 200
    assert client.get(f"/company/scenarios/{sid}", headers=_auth(m, u["a"])).status_code == 404         # archived

def test_scenario_cross_company(client, w):
    m, u, _ = w
    sid = client.post("/company/scenarios", headers=_auth(m, u["a"]), json=SC).json()["id"]
    assert client.get(f"/company/scenarios/{sid}", headers=_auth(m, u["b"])).status_code == 404
    assert client.post(f"/company/scenarios/{sid}/run", headers=_auth(m, u["b"])).status_code == 404
    assert client.get("/company/scenarios", headers=_auth(m, u["b"])).json()["count"] == 0

def test_scenario_other_company_branch_rejected(client, w):
    m, u, ids = w
    with Session(m.engine) as s:
        bbr = s.exec(select(m.CompanyBranch).where(m.CompanyBranch.company_id == ids["cb"])).first().id
    assert client.post("/company/scenarios", headers=_auth(m, u["a"]), json={**SC, "branch_id": bbr}).status_code == 404

# ── Action Center ──
def _decision(client, m, owner):
    d = client.get("/company/executive-intelligence", headers=_auth(m, owner)).json()
    sid = (d["risks"] + d["opportunities"])[0]["id"]
    return client.post("/company/recommendations/to-decision", headers=_auth(m, owner), json={"signal_id": sid}).json()

def test_action_create_summary_filters(client, w):
    m, u, _ = w
    dec = _decision(client, m, u["a"])
    r = client.post("/company/actions", headers=_auth(m, u["a"]), json={"decision_id": dec["decision_id"], "title": "راجع التكاليف", "owner": "Ali", "due_date": "2000-01-01", "priority": "P1"})
    assert r.status_code == 200
    lst = client.get("/company/actions", headers=_auth(m, u["a"])).json()
    assert lst["summary"]["total"] >= 2 and lst["summary"]["overdue"] >= 1
    assert all(x["owner"] == "Ali" for x in client.get("/company/actions?owner=Ali", headers=_auth(m, u["a"])).json()["actions"])
    assert client.get("/company/actions?q=التكاليف", headers=_auth(m, u["a"])).json()["count"] == 1
    assert client.get("/company/actions?due_from=bad", headers=_auth(m, u["a"])).status_code == 422
    assert lst["actions"][0]["decision_title"]

def test_action_validation(client, w):
    m, u, _ = w
    aid = _decision(client, m, u["a"])["action_ids"][0]
    up = lambda body: client.post("/company/actions/update", headers=_auth(m, u["a"]), json={"id": aid, **body})
    assert up({"progress": 150}).status_code == 400
    assert up({"progress": -1}).status_code == 400
    assert up({"due_date": "31-12-2026"}).status_code == 422
    r = up({"owner": "Sara", "due_date": "2026-12-31", "note": "بدأنا"})
    assert r.status_code == 200 and r.json()["action"]["owner"] == "Sara" and "بدأنا" in r.json()["action"]["notes"]
    assert up({"status": "completed", "progress": 20}).json()["action"]["progress"] == 100
    assert up({"status": "in_progress"}).status_code == 409
    h = client.get(f"/company/actions/{aid}/history", headers=_auth(m, u["a"])).json()["history"]
    assert len(h) >= 2

def test_action_create_other_company_decision_404(client, w):
    m, u, _ = w
    did = _decision(client, m, u["a"])["decision_id"]
    assert client.post("/company/actions", headers=_auth(m, u["b"]), json={"decision_id": did, "title": "x"}).status_code == 404
    assert client.get(f"/company/actions/1/history", headers=_auth(m, u["b"])).status_code == 404

# ── Decision memory ──
def test_memory_no_similar(client, w):
    m, u, _ = w
    did = _decision(client, m, u["a"])["decision_id"]
    r = client.get(f"/company/decisions/{did}/memory", headers=_auth(m, u["a"])).json()
    assert r["similar"]["items"] == [] and r["outcome"]["status"] == "pending_measurement"

def test_memory_similar_same_company(client, w):
    m, u, _ = w
    d1 = _decision(client, m, u["a"])["decision_id"]; d2 = _decision(client, m, u["a"])["decision_id"]
    items = client.get(f"/company/decisions/{d2}/memory", headers=_auth(m, u["a"])).json()["similar"]["items"]
    assert [x["id"] for x in items] == [d1] and "same_kpi" in items[0]["reasons"]

def test_memory_cross_company_and_unauthorized(client, w):
    m, u, _ = w
    did = _decision(client, m, u["a"])["decision_id"]
    assert client.get(f"/company/decisions/{did}/memory", headers=_auth(m, u["b"])).status_code == 404
    assert client.get(f"/company/decisions/{did}/memory", headers=_auth(m, u["staff"])).status_code == 403
    assert client.get("/company/decision-memory", headers=_auth(m, u["a"])).status_code == 400   # missing KPI/problem

def test_measure_insufficient_then_verified(client, w):
    m, u, ids = w
    did = _decision(client, m, u["a"])["decision_id"]
    r = client.post("/company/decisions/measure", headers=_auth(m, u["a"]), json={"decision_id": did}).json()
    assert r["outcome_status"] in ("pending_measurement", "insufficient_data") and r.get("actual_value") is None
    with Session(m.engine) as s:
        d = s.get(m.CompanyDecision, did); d.created_at = datetime(2026, 8, 5); d.metric_id = "net_sales"; d.baseline_value = 80000.0
        s.add(d); s.commit()
    r = client.post("/company/decisions/measure", headers=_auth(m, u["a"]), json={"decision_id": did}).json()
    assert r["outcome_status"] == "verified" and r["measurement_period"] == "2026-09" and r["actual_change"] == 20000.0
    assert r["data_source"] == "companyentry" and "caveat" in r

def test_measure_invalid_kpi_not_verified(client, w):
    m, u, _ = w
    did = _decision(client, m, u["a"])["decision_id"]
    with Session(m.engine) as s:
        d = s.get(m.CompanyDecision, did); d.metric_id = "dio"; d.created_at = datetime(2026, 8, 5); s.add(d); s.commit()
    assert client.post("/company/decisions/measure", headers=_auth(m, u["a"]), json={"decision_id": did}).json()["outcome_status"] == "not_verified"
