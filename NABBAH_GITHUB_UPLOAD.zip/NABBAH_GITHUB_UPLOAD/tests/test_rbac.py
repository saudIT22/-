"""
NABBAH — اختبارات أمان الصلاحيات الشاملة (RBAC — Phase 1.3)
تثبّت أن كل دور يصل لما يخصّه فقط، ولا يتجاوز صلاحياته.
تختبر: مصفوفة الصلاحيات، أمان مستوى العمود، الـhelpers الموحّدة.
"""
import pytest


# ═══════════ مصفوفة الصلاحيات (كل دور × مورد × إجراء) ═══════════
class TestOwnerRole:
    """المالك: كل الصلاحيات."""
    def test_owner_all_view(self, app_module):
        assert app_module.check_permission("owner", "finance", "view") is True
    def test_owner_all_edit(self, app_module):
        assert app_module.check_permission("owner", "hr", "edit") is True
    def test_owner_all_manage(self, app_module):
        assert app_module.check_permission("owner", "settings", "manage") is True
    def test_owner_any_resource(self, app_module):
        # المالك يصل لأي مورد حتى غير المعرّف
        assert app_module.check_permission("owner", "anything", "manage") is True


class TestAccountantRole:
    """المحاسب: المالية فقط — لا تشغيل، لا HR تفصيلي."""
    def test_accountant_finance_yes(self, app_module):
        assert app_module.check_permission("accountant", "finance", "view") is True
    def test_accountant_finance_edit(self, app_module):
        assert app_module.check_permission("accountant", "finance", "edit") is True
    def test_accountant_cashflow_yes(self, app_module):
        assert app_module.check_permission("accountant", "cashflow", "view") is True
    def test_accountant_ops_no(self, app_module):
        assert app_module.check_permission("accountant", "ops", "view") is False
    def test_accountant_hr_no(self, app_module):
        assert app_module.check_permission("accountant", "hr", "edit") is False
    def test_accountant_inventory_no(self, app_module):
        assert app_module.check_permission("accountant", "inventory", "view") is False


class TestManagerRole:
    """مدير الفرع: تشغيل فرعه — لا مالية."""
    def test_manager_sales_edit(self, app_module):
        assert app_module.check_permission("manager", "sales", "edit") is True
    def test_manager_ops_edit(self, app_module):
        assert app_module.check_permission("manager", "ops", "edit") is True
    def test_manager_finance_no(self, app_module):
        assert app_module.check_permission("manager", "finance", "view") is False
    def test_manager_cashflow_no(self, app_module):
        assert app_module.check_permission("manager", "cashflow", "view") is False
    def test_manager_hr_view_only(self, app_module):
        # يرى HR لكن لا يعدّله
        assert app_module.check_permission("manager", "hr", "view") is True
        assert app_module.check_permission("manager", "hr", "edit") is False


class TestStaffRole:
    """الموظف: إدخال تشغيلي فقط — لا مالية، لا تقارير."""
    def test_staff_input_edit(self, app_module):
        assert app_module.check_permission("staff", "input", "edit") is True
    def test_staff_finance_no(self, app_module):
        assert app_module.check_permission("staff", "finance", "view") is False
    def test_staff_reports_no(self, app_module):
        assert app_module.check_permission("staff", "reports", "view") is False
    def test_staff_decisions_no(self, app_module):
        assert app_module.check_permission("staff", "decisions", "view") is False


class TestUnknownRole:
    """دور غير معروف → أقل صلاحية (staff)، لا كل شيء."""
    def test_unknown_role_no_finance(self, app_module):
        assert app_module.check_permission("random_role", "finance", "manage") is False
    def test_empty_role_safe(self, app_module):
        # دور فارغ لا يُعطى صلاحيات المالك
        assert app_module.check_permission("", "finance", "view") is False
    def test_none_role_safe(self, app_module):
        assert app_module.check_permission(None, "finance", "manage") is False


# ═══════════ أمان مستوى العمود (Column-Level Security) ═══════════
class TestSensitiveFields:
    """الحقول المالية الحساسة (رواتب، هوامش) تُخفى عن غير المصرّح لهم."""
    def test_staff_cannot_see_salary(self, app_module):
        data = {"sales": 1000, "salary": 5000}
        filtered = app_module.filter_sensitive_fields(data, "staff")
        assert "salary" not in filtered
        assert filtered.get("sales") == 1000  # غير الحساس يبقى

    def test_manager_cannot_see_margin(self, app_module):
        data = {"sales": 1000, "margin": 25}
        filtered = app_module.filter_sensitive_fields(data, "manager")
        assert "margin" not in filtered

    def test_owner_sees_all(self, app_module):
        data = {"sales": 1000, "salary": 5000, "margin": 25}
        filtered = app_module.filter_sensitive_fields(data, "owner")
        assert filtered.get("salary") == 5000
        assert filtered.get("margin") == 25

    def test_accountant_sees_sensitive(self, app_module):
        data = {"salary": 5000, "margin": 25}
        filtered = app_module.filter_sensitive_fields(data, "accountant")
        assert filtered.get("salary") == 5000

    def test_can_see_sensitive_matrix(self, app_module):
        assert app_module.can_see_sensitive_financials("owner") is True
        assert app_module.can_see_sensitive_financials("accountant") is True
        assert app_module.can_see_sensitive_financials("manager") is False
        assert app_module.can_see_sensitive_financials("staff") is False


# ═══════════ الـhelpers الموحّدة الجديدة ═══════════
class TestPermissionHelpers:
    """user_can و require_permission — التوحيد."""
    def test_user_can_owner(self, app_module, clean_db):
        from sqlmodel import Session
        m = app_module
        with Session(m.engine) as s:
            u = m.User(name="O", email="own@t.com", password_hash="x")
            s.add(u); s.commit(); s.refresh(u)
            c = m.Company(name="C", owner_id=u.id, is_active=1)
            s.add(c); s.commit(); s.refresh(c)
            u.company_id = c.id; s.add(u); s.commit(); s.refresh(u)
            # المالك يستطيع كل شيء
            assert m.user_can(s, u, "finance", "manage") is True

    def test_require_permission_raises(self, app_module, clean_db):
        from sqlmodel import Session
        m = app_module
        with Session(m.engine) as s:
            owner = m.User(name="O2", email="o2@t.com", password_hash="x")
            s.add(owner); s.commit(); s.refresh(owner)
            c = m.Company(name="C2", owner_id=owner.id, is_active=1)
            s.add(c); s.commit(); s.refresh(c)
            # موظف في الشركة
            staff = m.User(name="S", email="s@t.com", password_hash="x", company_id=c.id)
            s.add(staff); s.commit(); s.refresh(staff)
            m.CompanyMember(company_id=c.id, name="S", email="s@t.com", role="staff")
            # الموظف يُرفض من المالية
            with pytest.raises(m.HTTPException) as exc:
                m.require_permission(s, staff, "finance", "view")
            assert exc.value.status_code == 403


# ═══════════ منع تصعيد الصلاحيات (Privilege Escalation) ═══════════
class TestPrivilegeEscalation:
    """لا يمكن لدور أقل الوصول لصلاحيات دور أعلى."""
    def test_staff_cannot_escalate_to_finance(self, app_module):
        # الموظف لا يصل للمالية مهما كان الإجراء
        for action in ["view", "edit", "manage"]:
            assert app_module.check_permission("staff", "finance", action) is False

    def test_manager_cannot_access_finance(self, app_module):
        # مدير الفرع لا يصل للمالية
        for action in ["view", "edit", "manage"]:
            assert app_module.check_permission("manager", "finance", action) is False

    def test_accountant_cannot_manage_ops(self, app_module):
        # المحاسب لا يدير التشغيل
        assert app_module.check_permission("accountant", "ops", "manage") is False
