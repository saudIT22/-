"""
NABBAH — اختبارات سلامة البيانات (Data Integrity — Phase 1.4)
تثبّت أن التحقق من المدخلات يعمل: يقبل الصحيح، ينبّه على المشبوه،
ينظّف الأرقام، ولا يرفض بيانات صالحة.
"""
import pytest


# ═══════════ التحقق من المدخلات (validate_module_input) ═══════════
class TestValidInput:
    """البيانات الصحيحة تُقبل بلا تحذيرات."""
    def test_clean_data_no_warnings(self, app_module):
        result = app_module.validate_module_input({"مبيعات": 100000, "عملاء": 500})
        assert len(result["warnings"]) == 0
        assert result["cleaned"]["مبيعات"] == 100000

    def test_positive_values_pass(self, app_module):
        result = app_module.validate_module_input({"تكلفة البضاعة": 50000})
        assert len(result["warnings"]) == 0


class TestNegativeValues:
    """القيم السالبة في حقول موجبة → تحذير (لا رفض — قد تكون مرتجعات)."""
    def test_negative_sales_warns(self, app_module):
        result = app_module.validate_module_input({"مبيعات": -5000})
        assert len(result["warnings"]) > 0
        # لكن القيمة تُحفظ (لا رفض قسري)
        assert result["cleaned"]["مبيعات"] == -5000

    def test_negative_customers_warns(self, app_module):
        result = app_module.validate_module_input({"عدد العملاء": -10})
        assert len(result["warnings"]) > 0


class TestExtremeValues:
    """القيم الضخمة (أخطاء كتابية محتملة) → تحذير."""
    def test_huge_value_warns(self, app_module):
        result = app_module.validate_module_input({"مبيعات": 99_999_999_999_999})
        assert len(result["warnings"]) > 0

    def test_normal_large_ok(self, app_module):
        # مليون عادي — لا تحذير
        result = app_module.validate_module_input({"مبيعات": 1_000_000})
        assert len(result["warnings"]) == 0


class TestNumberCleaning:
    """تنظيف الأرقام (فواصل، نسب)."""
    def test_comma_separated_cleaned(self, app_module):
        result = app_module.validate_module_input({"مبيعات": "120,000"})
        assert result["cleaned"]["مبيعات"] == 120000.0

    def test_percent_cleaned(self, app_module):
        result = app_module.validate_module_input({"نسبة": "25%"})
        assert result["cleaned"]["نسبة"] == 25.0


class TestDescriptiveText:
    """النصوص الوصفية تُقبل كما هي (لا تُحوّل لأرقام)."""
    def test_text_preserved(self, app_module):
        result = app_module.validate_module_input({"ملاحظة": "أكبر تعطّل في يونيو"})
        assert result["cleaned"]["ملاحظة"] == "أكبر تعطّل في يونيو"

    def test_source_marker_preserved(self, app_module):
        result = app_module.validate_module_input({"__source": "excel", "مبيعات": 1000})
        assert result["cleaned"]["__source"] == "excel"


class TestEdgeCases:
    """الحالات الحدّية — لا انهيار."""
    def test_empty_dict(self, app_module):
        result = app_module.validate_module_input({})
        assert result["cleaned"] == {}
        assert result["warnings"] == []

    def test_non_dict_safe(self, app_module):
        result = app_module.validate_module_input("not a dict")
        assert result["cleaned"] == {}

    def test_empty_keys_skipped(self, app_module):
        result = app_module.validate_module_input({"": 100, "مبيعات": 200})
        assert "" not in result["cleaned"]
        assert result["cleaned"]["مبيعات"] == 200

    def test_none_values_handled(self, app_module):
        result = app_module.validate_module_input({"مبيعات": None, "عملاء": 100})
        # None يُقبل كما هو أو يُتجاهل — لا انهيار
        assert "عملاء" in result["cleaned"]


# ═══════════ التكامل مع محرك الجودة الموجود ═══════════
class TestQualityEngineIntact:
    """محرك الجودة الموجود لم يُكسر."""
    def test_confidence_flag_still_works(self, app_module):
        result = app_module.compute_confidence_flag(45)
        assert result["flag"] is True

    def test_quality_rules_empty(self, app_module):
        score, flags = app_module.check_data_quality_rules([])
        assert score == 0


# ═══════════ الحفظ الفعلي عبر endpoint ═══════════
def test_save_returns_warnings(client, app_module, clean_db):
    """endpoint الحفظ يُرجع تحذيرات القيم المشبوهة."""
    # نسجّل مستخدم + شركة
    client.post("/register", json={
        "name": "O", "email": "int@t.com", "password": "Pass12345",
        "business_name": "IntCo", "phone": "0500000000",
    })
    r = client.post("/login", json={"email": "int@t.com", "password": "Pass12345"})
    tok = r.json().get("token")
    if not tok:
        pytest.skip("تعذّر تسجيل الدخول")
    # نحفظ بيانات فيها قيمة سالبة
    rs = client.post("/company/module/save",
                     headers={"Authorization": f"Bearer {tok}"},
                     json={"module": "sales", "period": "1/2026", "data": {"مبيعات": -5000}})
    if rs.status_code == 200:
        # يجب أن يحفظ لكن مع تحذير
        assert "warnings" in rs.json()
