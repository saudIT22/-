# NABBAH Phase 2.3 — Implementation Report

## Status
Six requested features implemented and unit-tested. API/database tests are written and run in CI after upload. **Phase 2.2's CI gate is still open**; both phases close together when the CI run is green.

## What was built
| # | Feature | Classification | Where |
|---|---|---|---|
| 1 | Executive Intelligence panel on the existing dashboard: summary, revenue/profit vs target, margin, branches, risks, opportunities, recommendations, data-quality warnings, forecast | IMPLEMENTED · TESTED (engine + browser render) · API NOT EXECUTED | `GET /company/executive-intelligence`, `nabbah-exec-intel.js`, `company-dashboard.html` |
| 2 | Risks & opportunities: declining sales, negative margin, high expenses, margin below target, missing data, inconsistent data, high inventory, low repeat, branch decline / below target / below average; opportunities: momentum, branch margin gap, beating target | IMPLEMENTED · TESTED | `phase23/intelligence_engine.py` |
| 3 | Recommendations: problem, evidence, recommendation, priority, expected impact (estimate), confidence, suggested action, success metric | IMPLEMENTED · TESTED | same; optional AI narrative via `?ai=1` using existing Gemini 3-model fallback + quality gate |
| 4 | Decisions & actions: recommendation → decision + tasks; owner, due date, status, progress; expected vs actual impact; audit log | IMPLEMENTED · engine TESTED · API NOT EXECUTED | `/company/recommendations/to-decision`, `/company/actions`, `/company/actions/update`, `/company/decisions/measure` |
| 5 | Forecast: sales, profit, per-branch; base/best/worst from the data's own volatility; confidence rule; assumptions; target gap | IMPLEMENTED · TESTED | `phase23/forecast_engine.py` |
| 6 | Data quality: missing values, duplicates, invalid values, zero customers with sales, incorrect margins, missing branch, inconsistent totals | IMPLEMENTED · TESTED | `run_quality_checks` |

## Key rules
- No number is produced by AI; AI is optional narrative and is not called when the gate says BLOCK.
- Every signal shows its rule (threshold), KPI, source, severity, and an impact formula; impacts are labelled estimates.
- Client-sent numbers are ignored when converting a recommendation: the signal is recomputed server-side.
- Actual impact is VERIFIED only when a full month after the decision has data; otherwise `insufficient_data`.
- Completed/cancelled tasks cannot be edited (409); "completed" forces progress to 100%.
- Forecast refuses below 3 consecutive months and names the missing months; outliers are flagged with MAD, never removed.
- Old fixed ±12% scenarios in `/company/predictions` are now labelled "افتراض ثابت — ليس مشتقاً من بياناتك".

## Database
Additive only — see `docs/migrations/2_3_001_decisions_actions.sql`. New table `companyaction`; 9 nullable columns on `companydecision`. Applied automatically on boot. No existing data changed.

## Permissions
View executive intelligence: owner or finance:view (accountant). Create decisions / update tasks / measure: decisions:edit (owner). Staff and managers: 403. Every query is scoped by company_id and active branches.

## Tests (raw output: `docs/test_execution_output.txt`)
| Suite | Result |
|---|---|
| Phase 2.1 finance / trust / rounding | 38 / 22 / 19 passed |
| Phase 2.2 engines / periods / legacy | 84 / 26 / 6 passed |
| **Phase 2.3 engine (new)** | **53 passed** |
| Security static checks | 17 passed |
| **Executed total** | **265 passed · 0 failed** |
| NOT EXECUTED (no pytest here) | 13 files, 102 test functions, incl. 11 new Phase 2.3 API tests — run in CI |

Browser check (Playwright, real engine output): all sections render in Arabic RTL, no JS errors, decision form opens.

## Bugs found and fixed during this work
1. Outlier detection (IQR) missed a real spike with 6 months of data → replaced with MAD + floor.
2. Decision measurement would have computed a margin for growth-based decisions → per-metric measurement.
3. Arabic UI showed English severity/confidence codes → localized.

## Not done / remaining
- Saved, user-defined scenarios (spec unit B) — not started; old what-if remains.
- Decision memory linked to outcomes (unit H) — decisions now store expected/actual impact, but no "similar past decisions" view yet.
- A separate actions page — actions are reachable through the API and the panel; no dedicated screen yet.
- Rule texts inside signals are English technical formulas.
