# Upload to GitHub (supersedes all earlier packages)
Upload the CONTENTS of NABBAH_GITHUB_UPLOAD to the repository ROOT, keeping folders. Keep your existing requirements.txt.

Replace: main.py, i18n.js, nabbah-sidebar.js, nabbah-exec-intel.js, company-dashboard.html, pytest.ini, .github/workflows/tests.yml
Add: company-actions.html, company-scenarios.html, .gitignore (merge if you already have one)
Add/replace folders: phase21/, phase22/, phase23/, tests/, tools/, docs/

Then GitHub → Actions → "NABBAH Tests": two jobs run — "test" and "runtime-ui".
Download the artifact "phase23-runtime-screenshots" and send it with the job result.
