-- NABBAH Phase 2.3 — migration 2_3_002 (PostgreSQL). Additive only.
-- Applied AUTOMATICALLY on boot: table via create_all(), columns via auto_sync_columns().
-- Running it manually is idempotent.

CREATE TABLE IF NOT EXISTS companyscenario (
  id SERIAL PRIMARY KEY, company_id INTEGER NOT NULL, branch_id INTEGER,
  created_by VARCHAR DEFAULT '', name VARCHAR DEFAULT '', description VARCHAR DEFAULT '',
  scenario_type VARCHAR DEFAULT 'custom', base_period VARCHAR DEFAULT '',
  assumptions VARCHAR DEFAULT '{}', baseline_values VARCHAR DEFAULT '{}',
  scenario_values VARCHAR DEFAULT '{}', results VARCHAR DEFAULT '{}',
  status VARCHAR DEFAULT 'draft', created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP, ran_at TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_companyscenario_company_id ON companyscenario (company_id);
CREATE INDEX IF NOT EXISTS ix_companyscenario_branch_id ON companyscenario (branch_id);

ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS problem_type VARCHAR DEFAULT '';
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS decision_type VARCHAR DEFAULT '';
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS measurement_period VARCHAR DEFAULT '';
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS outcome_status VARCHAR DEFAULT '';
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS outcome_notes VARCHAR DEFAULT '';
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS created_by VARCHAR DEFAULT '';
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS data_source VARCHAR DEFAULT '';
-- Scenarios are soft-deleted (status='archived'); no rows are ever removed.
-- Rollback: DROP TABLE companyscenario; the companydecision columns are nullable and can stay.
