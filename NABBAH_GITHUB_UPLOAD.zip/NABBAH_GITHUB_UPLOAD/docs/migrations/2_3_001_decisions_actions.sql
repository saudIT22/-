-- NABBAH Phase 2.3 — migration 2_3_001 (PostgreSQL)
-- Applied AUTOMATICALLY on boot: columns via auto_sync_columns(), table via create_all().
-- This file is the auditable record; running it manually is idempotent and safe.
-- Additive only: no data changed, no column renamed or retyped.

ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS branch_id INTEGER;
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS metric_id VARCHAR DEFAULT '';
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS baseline_value DOUBLE PRECISION;
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS expected_impact_value DOUBLE PRECISION;
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS actual_value DOUBLE PRECISION;
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS actual_impact_value DOUBLE PRECISION;
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS impact_status VARCHAR DEFAULT '';
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS source_signal VARCHAR DEFAULT '';
ALTER TABLE companydecision ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP;

CREATE TABLE IF NOT EXISTS companyaction (
  id SERIAL PRIMARY KEY,
  company_id INTEGER NOT NULL,
  decision_id INTEGER NOT NULL,
  branch_id INTEGER,
  title VARCHAR DEFAULT '', description VARCHAR DEFAULT '', owner VARCHAR DEFAULT '',
  priority VARCHAR DEFAULT 'P2', start_date VARCHAR DEFAULT '', due_date VARCHAR DEFAULT '',
  status VARCHAR DEFAULT 'not_started', progress INTEGER DEFAULT 0, notes VARCHAR DEFAULT '',
  created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_companyaction_company_id ON companyaction (company_id);
CREATE INDEX IF NOT EXISTS ix_companyaction_decision_id ON companyaction (decision_id);
CREATE INDEX IF NOT EXISTS ix_companyaction_branch_id ON companyaction (branch_id);
CREATE INDEX IF NOT EXISTS ix_companydecision_branch_id ON companydecision (branch_id);

-- Rollback (only if no Phase 2.3 data needs keeping):
--   DROP TABLE companyaction;  -- the companydecision columns are nullable and can stay.
