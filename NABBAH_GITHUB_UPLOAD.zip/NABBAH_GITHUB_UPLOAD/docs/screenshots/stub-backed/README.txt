These screenshots were rendered from the real pages with a LOCAL STUB backend
(engine-computed JSON; action list = fixture). They are NOT runtime evidence.
Runtime screenshots are produced by CI into docs/screenshots/phase23-runtime/.
