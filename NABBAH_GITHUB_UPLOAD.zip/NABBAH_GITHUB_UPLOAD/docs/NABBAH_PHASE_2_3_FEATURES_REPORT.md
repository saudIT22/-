# NABBAH Phase 2.3 — Saved Scenarios, Action Center, Decision Memory, Localized Rules

## 1. Execution status
**Partially completed — code complete, runtime API verification pending.** All four features are implemented, wired front-to-back, unit-tested and visually checked. The FastAPI/database tests (14 files, 116 tests) could not run here (no pytest/FastAPI, no network) and run in GitHub Actions after upload.

## 2. Features
| Feature | Backend | Frontend | Tests |
|---|---|---|---|
| Saved what-if scenarios | `CompanyScenario` table; create/list/get/update/run/compare/archive; Decimal engine with validation (−90%..+300%), cost breakdown when available, honest warnings | `company-scenarios.html`: summary tiles, scenario cards, create card, form with field-level validation, Actual-vs-Scenario table | 23 engine + 6 API |
| Action Center | list with summary, search, filters (status/owner/branch/due dates), sort; create; update (status, progress 0–100 enforced, owner, due date validated, timestamped notes); history from audit log | `company-actions.html`: KPI tiles, Kanban board + table, detail drawer with edit form, notes, readable history, decision memory | 3 API (+ earlier lifecycle tests) |
| Decision memory & outcomes | 7 new decision columns; outcome statuses; measurement with completeness rules; similar decisions with stated reasons; causality caveat | memory section in drawer; "past decisions" on each recommendation | 18 engine + 5 API |
| Localized rule texts | `rule_catalog.py`: 27 rule codes with rule_code / technical_expression / threshold / KPI / AR+EN title, description, formula, action; fallback chain | panel shows user text; technical rule in collapsible "التفاصيل الفنية" | 10 engine incl. i18n validation |

## 3. Files created
`phase23/scenario_engine.py`, `phase23/decision_memory.py`, `phase23/rule_catalog.py`, `phase23/test_phase23_features.py`, `company-scenarios.html`, `company-actions.html`, `tests/test_api_phase23_features.py`, `docs/migrations/2_3_002_scenarios_memory.sql`, `docs/screenshots/*.png` (10), this report.

## 4. Files modified
- `main.py` — `CompanyScenario` model; 7 decision columns + auto-sync list; `_load_p23_mod`; scenario endpoints (7); `POST /company/actions`, `GET /company/actions/{id}/history`; upgraded `GET /company/actions` and `POST /company/actions/update`; rewritten `POST /company/decisions/measure`; `GET /company/decisions/{id}/memory`, `GET /company/decision-memory`; to-decision stores problem/decision type and creator; page routes.
- `phase23/intelligence_engine.py`, `phase23/forecast_engine.py` — every signal, data-quality warning, forecast warning and assumption carries localized texts, rule code, technical expression, threshold.
- `nabbah-exec-intel.js` — dark theme tokens, localized rules, technical details section, past-decisions lookup.
- `i18n.js` — 128 keys added (no existing key changed; a clash with `mem.title` was caught and avoided by using the `dm.` prefix).
- `nabbah-sidebar.js` — "السيناريوهات المحفوظة" and "مركز الإجراءات".
- `.github/workflows/tests.yml` — runs the new suite.

## 5. Authorization
| Endpoint group | View | Edit | Delete |
|---|---|---|---|
| Scenarios | owner, finance:view | owner, finance:edit (accountant) | owner (soft archive) |
| Actions | decisions:view | decisions:edit (owner) | — |
| Decision memory / measure | finance:view or owner | measure: owner | — |
All queries filter by `company_id`; records of another company return 404. Scenario branch must belong to the company. Financial results are always recomputed server-side.

## 6. Outcome rules (no causal claims)
`verified` = a complete month after the decision, every branch in scope reported, supported KPI, baseline stored. `measured` = computed but some branches missing. `insufficient_data`, `pending_measurement`, `not_verified` (bad KPI/baseline), `cancelled`. Every response carries the caveat that results show what happened after the decision, not that it caused it.

## 7. Tests (raw output: `docs/test_execution_output.txt`)
| Suite | Result |
|---|---|
| Phase 2.1 / 2.2 regression | 38 + 22 + 19 + 84 + 26 + 6 passed |
| Phase 2.3 engine | 53 passed |
| **Phase 2.3 features (new)** | **51 passed** |
| Security static checks | 17 passed |
| Frontend JS syntax (pages, component, sidebar, i18n) | all OK |
| **Executed** | **316 passed · 0 failed** |
| NOT EXECUTED | 14 pytest files / 116 tests — `No module named pytest` |

## 8. Visual verification
Playwright rendered the real pages and component. API responses came from a local stub: executive intelligence, scenario results and memory outcomes were computed by the real engines; the action list was a hand-built fixture shaped like the endpoint (its aggregation lives in `main.py`, which cannot run here). Checked: Arabic RTL, English LTR, 390 px mobile; zero JS errors on all 10 captures.

Issues found visually and fixed: sidebar button overlapping page titles; drawer form fields side by side and the slider overflowing; raw codes in Arabic text (`gross_margin`, recommendation IDs, `not_started/0 -> in_progress/40`); zero shown as a gain in green; unlabeled date filters; forecast assumptions in English inside the Arabic panel.

## 9. Remaining
- Runtime API/DB verification — run CI after upload.
- Action creation from a decision exists in the API; the UI creates actions only through "حوّل لقرار".
- Similarity is rule-based; semantic search can come later.
- Browser date pickers show their native format.
