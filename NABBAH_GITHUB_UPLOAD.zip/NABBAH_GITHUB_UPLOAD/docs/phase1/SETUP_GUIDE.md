# NABBAH — دليل الإعداد (Setup Guide)
**Phase 1.1** · إعداد الأمان والاختبارات

---

## ١. متغيّرات البيئة المطلوبة (Railway Variables)

### حرجة (يجب ضبطها للإنتاج)
| المتغيّر | الوصف | مثال |
|---|---|---|
| `SECRET_KEY` | مفتاح توقيع JWT — **الإقلاع يفشل بدونه في الإنتاج** | سلسلة عشوائية طويلة (48+ حرف) |
| `ADMIN_KEY` | مفتاح لوحة الإدارة | سلسلة قوية سرّية |
| `DATABASE_URL` | رابط PostgreSQL | يوفّره Railway تلقائياً |
| `GEMINI_API_KEY` | مفتاح Gemini للذكاء | من Google AI Studio |

### اختيارية
| المتغيّر | الوصف |
|---|---|
| `ALLOWED_ORIGINS` | نطاقات CORS إضافية (comma-separated) |
| `EXTRA_ORIGIN` | نطاق CORS إضافي واحد |
| `TRIAL_CODE` | كود التجربة المجانية |
| `ENVIRONMENT` | `production` (افتراضي) / `development` |

### كيف تولّد SECRET_KEY قوي
```bash
python3 -c "import secrets; print(secrets.token_urlsafe(48))"
```
انسخ الناتج والصقه في Railway Variables → `SECRET_KEY`.

---

## ٢. تشغيل الاختبارات محلياً

```bash
cd nabbah_tests
bash run_tests.sh
```

أو يدوياً:
```bash
export TESTING=true
export DATABASE_URL="sqlite:///./test_nabbah.db"
export SECRET_KEY="test-only"
export ADMIN_KEY="test-admin"
pip install pytest httpx
python3 -m pytest tests/ -v
```

---

## ٣. بنية الملفات

```
nabbah_tests/
├── pytest.ini                    ← إعداد pytest
├── requirements-test.txt         ← متطلبات الاختبار
├── run_tests.sh                  ← تشغيل آمن
├── tests/
│   ├── conftest.py               ← إعداد + حماية قاعدة الإنتاج
│   ├── test_financial_calculations.py
│   ├── test_auth.py
│   ├── test_company_isolation.py
│   ├── test_permissions.py
│   ├── test_endpoints.py
│   └── test_integrity_ai.py
├── docs/
│   ├── SECURITY_HARDENING_REPORT.md
│   └── SETUP_GUIDE.md
└── .github/workflows/tests.yml   ← CI/CD تلقائي
```

---

## ٤. الأمان — نقاط حرجة

1. **الاختبارات لا تلمس الإنتاج أبداً** — حماية مضاعفة في `conftest.py` + `run_tests.sh` + CI.
2. **الإنتاج يفشل بلا SECRET_KEY** — لن تنشر بلا مفتاح دون أن تعرف.
3. **CORS مقيّد** — لا wildcard مع credentials.

---

## ٥. أين تضع الملفات في مستودعك

```
مستودع NABBAH/
├── main.py                       ← المحدّث (SECRET_KEY + CORS)
├── requirements.txt              ← موجود
├── tests/                        ← من nabbah_tests/tests/
├── pytest.ini                    ← من nabbah_tests/
├── run_tests.sh                  ← من nabbah_tests/
└── .github/workflows/tests.yml   ← من nabbah_tests/.github/
```
