# NABBAH Phase 2.3 — Runtime Verification

## Status: BLOCKED in this environment — runtime verification moved to CI
This sandbox cannot run the application: PyPI returns 403 through the network proxy, there is no package cache or mirror, only PyJWT is installed (no FastAPI, SQLModel, pytest, httpx, bcrypt), and no PostgreSQL exists. `pip install -r requirements.txt pytest httpx` was attempted and failed. No runtime result below is claimed unless it was executed.

## Executed here (raw output: docs/test_execution_output.txt)
| Check | Result |
|---|---|
| 9 engine/logic suites (Phase 2.1, 2.2, 2.3) | 316 passed · 0 failed |
| Static contract/scope/migration audit (`tools/static_contract_check.py`) | 0 problems |
| Frontend JS syntax (3 pages, component, sidebar, i18n, runtime script) | OK |
| `main.py` compile | OK |
| `git diff --check` equivalent on all 88 files (no repo history here) | clean |
| Secrets / test doubles / console.log in production files | none |
| `python -m pytest tests -v` | NOT EXECUTED — `No module named pytest` |

## Bugs found and fixed in this round
1. RBAC leak: decision-memory endpoints used the finance scope, so an accountant could read decision titles and outcomes that the permission matrix denies. Now uses the existing `decisions:view` resource (owner, manager).
2. Static-audit gaps (checker only): owner-only guards and variable-built fetch URLs were not recognised; fixed so the audit covers them.
Verified NOT to be bugs: `/company/decisions`, `/save`, `/close` are owner-only and `close` checks `company_id`.

## Delivered so CI produces the missing runtime evidence
- `tests/test_api_runtime_smoke.py` — real FastAPI app + DB: RBAC matrix (owner/accountant/manager/staff × scenario view/create/edit/archive, action view/create/update, memory, measure), IDOR matrix (Company B using Company A's real IDs on 10 endpoints), 9 scenario cases (±10% revenue/expenses, COGS, payroll, marketing, −90%, +300%), out-of-range/invalid/missing data, branch scenario, baseline rows unchanged, client-sent results ignored, progress 0/50/100/−1/101, lifecycle 409, memory statuses pending/verified/measured/cancelled, no causal wording.
- `.github/workflows/tests.yml` job `runtime-ui` — seeds an isolated SQLite DB (`tools/seed_runtime_db.py`, refuses anything else), starts the real app with uvicorn, creates scenarios/decisions/actions/measurements through the real API, then `tools/runtime_ui_check.mjs` opens the real pages in Chromium (AR, EN, 390 px, 820 px), records console errors, failed requests and HTTP ≥400, checks Arabic text for leaked codes, saves 13 screenshots + `runtime-report.json` to `docs/screenshots/phase23-runtime/`, and FAILS on any console error, server error, failing Phase 2.3 request, i18n leak, or cross-company visibility.

## Roles
The roles that exist in code are owner, accountant, manager, staff. There is no separate "finance" role; finance access is the `finance` resource (owner + accountant).

## Remaining (genuine)
- Run CI (push to GitHub) — first real execution of 116+ pytest tests and the browser job. Expect first-run failures in older Phase 1 suites that have never executed.
- PostgreSQL-specific migration run: CI uses SQLite; the SQL files are applied on Railway at boot (`auto_sync_columns`) — verify the first Railway boot log.
- `docs/screenshots/stub-backed/` holds last round's stub-rendered screenshots, labelled as not runtime evidence.
