# NABBAH Phase 2.2 — Closure Report

## Final status
**PHASE 2.2 NOT COMPLETE — REMEDIATION REQUIRED**

The only open blocker is execution: the API/database tests have not run yet. They run automatically in GitHub Actions once these files are uploaded. If that run is green, the status becomes **PHASE 2.2 COMPLETE — SUBJECT TO DOCUMENTED DEFERRED ITEMS**.

## Files modified
- `main.py` — `compute_company_metrics` now uses the central engine (LEGACY_COMPATIBLE) with the original code kept as fallback; `/company/intelligence` is period-aware (from the previous remediation).
- `phase21/nabbah_finance.py` — rounding modes, `quantize()`, `rounding_mode` in metadata, engine v1.1.
- `phase22/semantic_layer.py` — envelope reports `rounding_mode`.
- `phase22/legacy_adapters.py` — rewritten for both modes.
- `.github/workflows/tests.yml` — runs every suite; no deployment step.
- `pytest.ini`, `tests/conftest.py` — locate `main.py` reliably; dummy AI key for import.

## Files created
`phase21/test_rounding_modes.py`, `tools/rounding_impact_report.py`, `docs/NABBAH_ROUNDING_MIGRATION_PLAN.md`, this report; `tests/test_api_intelligence.py` extended to 22 tests.

## Test results (this environment, raw output in `docs/test_execution_output.txt`)
| Suite | Result |
|---|---|
| Finance engine | 38 passed |
| Trust layer | 22 passed |
| Rounding modes (new) | 19 passed |
| Phase 2.2 engines | 84 passed |
| Period aggregation | 26 passed |
| Legacy compatibility (production function) | 6 passed |
| Security static checks | 17 passed |
| **Executed** | **212 passed · 0 failed · 0 skipped** |
| **NOT EXECUTED** | 12 pytest files, 139 test functions — `No module named pytest` (no network) |

## Classification
| Item | Status |
|---|---|
| LEGACY_COMPATIBLE mode, default | IMPLEMENTED · TESTED |
| ACCOUNTING_HALF_UP mode | IMPLEMENTED · TESTED · NOT ENABLED |
| Production `compute_company_metrics` via engine | IMPLEMENTED · TESTED (0 diffs) |
| Period-aware `/company/intelligence` | IMPLEMENTED · unit TESTED · API NOT EXECUTED |
| API: auth, roles, tenant A/B, branch isolation, same-period rows, bad data, AI BLOCK | IMPLEMENTED · NOT EXECUTED |
| CI workflow | IMPLEMENTED · YAML validated · NOT EXECUTED |
| Historical record impact count | DEFERRED — needs `tools/rounding_impact_report.py` on a DB copy |
| Migration of the ~20 other margin calculations | DEFERRED — per plan |
| Enabling ACCOUNTING_HALF_UP | NOT IMPLEMENTED by design (awaiting approval) |

## Security (by code; runtime pending CI)
`company_id` + active-branch filter on the new query; RBAC before data access; client `company_id` ignored; AI not called on BLOCK; 503 without stack trace when engines are missing. No schema change, no data change, no deployment step in CI.

## Remaining limitations
Old pytest suites (written in Phase 1) have never run and may reveal issues in their first CI run. "Latest submission per branch wins" is a design assumption. LEGACY_COMPATIBLE inherits float precision limits.
