# Files to upload (Phase 1.6 → 2.3) — cumulative, supersedes all earlier packages

Upload everything to the repository ROOT, keeping folders. Keep your existing requirements.txt.


## (root) (11)
- .gitignore
- company-actions.html
- company-dashboard.html
- company-scenarios.html
- i18n.js
- main.py
- nabbah-exec-intel.js
- nabbah-sidebar.js
- pytest.ini
- requirements-test.txt
- run_tests.sh

## .github (1)
- .github/workflows/tests.yml

## docs (28)
- docs/NABBAH_PHASE_2_2_CLOSURE_REPORT.md
- docs/NABBAH_PHASE_2_3_FEATURES_REPORT.md
- docs/NABBAH_PHASE_2_3_REPORT.md
- docs/NABBAH_PHASE_2_3_RUNTIME_VERIFICATION.md
- docs/NABBAH_ROUNDING_MIGRATION_PLAN.md
- docs/UPLOAD_TO_GITHUB.md
- docs/migrations/2_3_001_decisions_actions.sql
- docs/migrations/2_3_002_scenarios_memory.sql
- docs/phase1/DATA_INTEGRITY_REPORT.md
- docs/phase1/ERROR_HANDLING_REPORT.md
- docs/phase1/FINAL_VERIFICATION_REPORT.md
- docs/phase1/RBAC_GAP_REMEDIATION.md
- docs/phase1/RBAC_SECURITY_REPORT.md
- docs/phase1/SECURITY_HARDENING_REPORT.md
- docs/phase1/SETUP_GUIDE.md
- docs/phase1/TENANT_ISOLATION_REPORT.md
- docs/screenshots/stub-backed/10_exec_intel_mobile_ar.png
- docs/screenshots/stub-backed/1_exec_intel_ar.png
- docs/screenshots/stub-backed/2_exec_intel_en.png
- docs/screenshots/stub-backed/3_scenarios_ar.png
- docs/screenshots/stub-backed/4_scenario_form_validation_ar.png
- docs/screenshots/stub-backed/5_scenarios_en.png
- docs/screenshots/stub-backed/6_actions_board_ar.png
- docs/screenshots/stub-backed/7_action_drawer_ar.png
- docs/screenshots/stub-backed/8_actions_table_en.png
- docs/screenshots/stub-backed/9_actions_mobile_ar.png
- docs/screenshots/stub-backed/README.txt
- docs/test_execution_output.txt

## phase21 (6)
- phase21/nabbah_finance.py
- phase21/nabbah_trust.py
- phase21/test_api_integration.py
- phase21/test_finance_engine.py
- phase21/test_rounding_modes.py
- phase21/test_trust_layer.py

## phase22 (10)
- phase22/ai_gateway.py
- phase22/analysis_engines.py
- phase22/kpi_engine.py
- phase22/legacy_adapters.py
- phase22/period_aggregation.py
- phase22/platform_bridge.py
- phase22/semantic_layer.py
- phase22/test_legacy_migration.py
- phase22/test_period_aggregation.py
- phase22/test_phase22_engines.py

## phase23 (7)
- phase23/decision_memory.py
- phase23/forecast_engine.py
- phase23/intelligence_engine.py
- phase23/rule_catalog.py
- phase23/scenario_engine.py
- phase23/test_phase23.py
- phase23/test_phase23_features.py

## tests (17)
- tests/conftest.py
- tests/test_api_intelligence.py
- tests/test_api_phase23.py
- tests/test_api_phase23_features.py
- tests/test_api_runtime_smoke.py
- tests/test_auth.py
- tests/test_company_isolation.py
- tests/test_data_integrity.py
- tests/test_endpoints.py
- tests/test_error_handling.py
- tests/test_financial_calculations.py
- tests/test_integrity_ai.py
- tests/test_permissions.py
- tests/test_rbac.py
- tests/test_rbac_endpoints.py
- tests/test_tenant_isolation.py
- tests/verify_security.py

## tools (4)
- tools/rounding_impact_report.py
- tools/runtime_ui_check.mjs
- tools/seed_runtime_db.py
- tools/static_contract_check.py
