# NABBAH — Rounding Migration Plan (for future approval — NOT executed)

## Current state (Option B, approved)
Engine default `DEFAULT_ROUNDING_MODE = LEGACY_COMPATIBLE`. Stored values and branch scores are unchanged (verified: 0 differences on 30,004 cases incl. ties, production function extracted from `main.py`).

| Mode | Rule | Status |
|---|---|---|
| LEGACY_COMPATIBLE | Exact binary value of the float, half-to-even (what Python `round()` did). Implemented with `Decimal(float).quantize(ROUND_HALF_EVEN)`. | Default, in production |
| ACCOUNTING_HALF_UP | Exact decimal value, ties away from zero. | Implemented, NOT enabled |

Examples: 12.25 → 12.2 vs 12.3 · 12.35 → 12.3 vs 12.4 · −12.25 → −12.2 vs −12.3 · 0.125 → 0.12 vs 0.13.
Limit of LEGACY_COMPATIBLE: float precision (~15–16 significant digits).

## Affected metrics, tables, columns
`companyentry.profit`, `.margin`, `.avg_invoice`, `.repeat_rate`, `.growth`, and `.branch_score` (derived from margin, growth, repeat rate, profit). Written by `compute_company_metrics` at `/company/entry` and in the two Excel/CSV import paths.

## Historical record count and before/after comparison
Not measurable from this environment (no database access). Run on a **copy**:
```
ALLOW_READONLY_REPORT=1 DATABASE_URL=<copy> python tools/rounding_impact_report.py
```
It reports rows scanned, rows that would change, companies affected and per-field counts. It is read-only. Growth is excluded because it needs the previous period.

## Required steps for any future switch
1. Owner approval of the report above.
2. Add a `rounding_mode` / `calculation_version` column to `companyentry` (schema migration, reviewed separately).
3. Rehearse on a non-production copy; compare before/after per row and per branch score.
4. Switch `DEFAULT_ROUNDING_MODE` only; keep old values in an audit table or keep `calculation_version` so every row states how it was computed.
5. Rollback: restore `DEFAULT_ROUNDING_MODE = LEGACY_COMPATIBLE` (one line) and, if rows were rewritten, restore them from the audit table.
